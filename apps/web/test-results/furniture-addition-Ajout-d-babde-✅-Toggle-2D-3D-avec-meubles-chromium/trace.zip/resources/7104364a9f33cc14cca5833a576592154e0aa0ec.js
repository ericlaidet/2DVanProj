/** <Typesetter>.getTransferables **/

troikaDefine(
function getTransferables(result) {
    const transferables = [];
    for (let p2 in result) {
      if (result[p2] && result[p2].buffer) {
        transferables.push(result[p2].buffer);
      }
    }
    return transferables;
  }
)
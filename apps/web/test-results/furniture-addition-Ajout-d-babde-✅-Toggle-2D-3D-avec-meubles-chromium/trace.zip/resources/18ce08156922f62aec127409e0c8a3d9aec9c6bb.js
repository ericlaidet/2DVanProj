/** <Typesetter>.init **/

troikaDefine(
function init(typesetter) {
    return function(args) {
      return new Promise((resolve) => {
        typesetter.typeset(args, resolve);
      });
    };
  }
)
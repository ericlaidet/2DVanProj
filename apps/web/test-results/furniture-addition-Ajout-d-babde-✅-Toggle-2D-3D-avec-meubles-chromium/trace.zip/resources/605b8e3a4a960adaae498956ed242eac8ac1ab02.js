/** <Typr Font Parser>.init **/

troikaDefine(
function init(typrFactory2, woff2otfFactory2, parserFactory2) {
    const Typr = typrFactory2();
    const woff2otf = woff2otfFactory2();
    return parserFactory2(Typr, woff2otf);
  }
)
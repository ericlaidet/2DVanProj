/** <<Typesetter> function dependency: createTypesetter>.init **/

troikaDefine(
function(){return (
function createTypesetter(resolveFonts, bidi) {
  const INF = Infinity;
  const DEFAULT_IGNORABLE_CHARS = /[\u00AD\u034F\u061C\u115F-\u1160\u17B4-\u17B5\u180B-\u180E\u200B-\u200F\u202A-\u202E\u2060-\u206F\u3164\uFE00-\uFE0F\uFEFF\uFFA0\uFFF0-\uFFF8]/;
  const lineBreakingWhiteSpace = `[^\\S\\u00A0]`;
  const BREAK_AFTER_CHARS = new RegExp(`${lineBreakingWhiteSpace}|[\\-\\u007C\\u00AD\\u2010\\u2012-\\u2014\\u2027\\u2056\\u2E17\\u2E40]`);
  function calculateFontRuns({ text, lang, fonts, style, weight, preResolvedFonts, unicodeFontsURL }, onDone) {
    const onResolved = ({ chars, fonts: parsedFonts }) => {
      let curRun, prevVal;
      const runs = [];
      for (let i4 = 0; i4 < chars.length; i4++) {
        if (chars[i4] !== prevVal) {
          prevVal = chars[i4];
          runs.push(curRun = { start: i4, end: i4, fontObj: parsedFonts[chars[i4]] });
        } else {
          curRun.end = i4;
        }
      }
      onDone(runs);
    };
    if (preResolvedFonts) {
      onResolved(preResolvedFonts);
    } else {
      resolveFonts(
        text,
        onResolved,
        { lang, fonts, style, weight, unicodeFontsURL }
      );
    }
  }
  function typeset({
    text = "",
    font,
    lang,
    sdfGlyphSize = 64,
    fontSize = 400,
    fontWeight = 1,
    fontStyle = "normal",
    letterSpacing = 0,
    lineHeight = "normal",
    maxWidth = INF,
    direction: direction2,
    textAlign = "left",
    textIndent = 0,
    whiteSpace = "normal",
    overflowWrap = "normal",
    anchorX = 0,
    anchorY = 0,
    metricsOnly = false,
    unicodeFontsURL,
    preResolvedFonts = null,
    includeCaretPositions = false,
    chunkedBoundsSize = 8192,
    colorRanges = null
  }, callback) {
    const mainStart = now2();
    const timings = { fontLoad: 0, typesetting: 0 };
    if (text.indexOf("\r") > -1) {
      console.info("Typesetter: got text with \\r chars; normalizing to \\n");
      text = text.replace(/\r\n/g, "\n").replace(/\r/g, "\n");
    }
    fontSize = +fontSize;
    letterSpacing = +letterSpacing;
    maxWidth = +maxWidth;
    lineHeight = lineHeight || "normal";
    textIndent = +textIndent;
    calculateFontRuns({
      text,
      lang,
      style: fontStyle,
      weight: fontWeight,
      fonts: typeof font === "string" ? [{ src: font }] : font,
      unicodeFontsURL,
      preResolvedFonts
    }, (runs) => {
      timings.fontLoad = now2() - mainStart;
      const hasMaxWidth = isFinite(maxWidth);
      let glyphIds = null;
      let glyphFontIndices = null;
      let glyphPositions = null;
      let glyphData = null;
      let glyphColors = null;
      let caretPositions = null;
      let visibleBounds = null;
      let chunkedBounds = null;
      let maxLineWidth = 0;
      let renderableGlyphCount = 0;
      let canWrap = whiteSpace !== "nowrap";
      const metricsByFont = /* @__PURE__ */ new Map();
      const typesetStart = now2();
      let lineXOffset = textIndent;
      let prevRunEndX = 0;
      let currentLine = new TextLine();
      const lines = [currentLine];
      runs.forEach((run) => {
        const { fontObj } = run;
        const { ascender, descender, unitsPerEm, lineGap, capHeight, xHeight } = fontObj;
        let fontData2 = metricsByFont.get(fontObj);
        if (!fontData2) {
          const fontSizeMult2 = fontSize / unitsPerEm;
          const calcLineHeight = lineHeight === "normal" ? (ascender - descender + lineGap) * fontSizeMult2 : lineHeight * fontSize;
          const halfLeading = (calcLineHeight - (ascender - descender) * fontSizeMult2) / 2;
          const caretHeight = Math.min(calcLineHeight, (ascender - descender) * fontSizeMult2);
          const caretTop = (ascender + descender) / 2 * fontSizeMult2 + caretHeight / 2;
          fontData2 = {
            index: metricsByFont.size,
            src: fontObj.src,
            fontObj,
            fontSizeMult: fontSizeMult2,
            unitsPerEm,
            ascender: ascender * fontSizeMult2,
            descender: descender * fontSizeMult2,
            capHeight: capHeight * fontSizeMult2,
            xHeight: xHeight * fontSizeMult2,
            lineHeight: calcLineHeight,
            baseline: -halfLeading - ascender * fontSizeMult2,
            // baseline offset from top of line height
            // cap: -halfLeading - capHeight * fontSizeMult, // cap from top of line height
            // ex: -halfLeading - xHeight * fontSizeMult, // ex from top of line height
            caretTop,
            caretBottom: caretTop - caretHeight
          };
          metricsByFont.set(fontObj, fontData2);
        }
        const { fontSizeMult } = fontData2;
        const runText = text.slice(run.start, run.end + 1);
        let prevGlyphX, prevGlyphObj;
        fontObj.forEachGlyph(runText, fontSize, letterSpacing, (glyphObj, glyphX, glyphY, charIndex) => {
          glyphX += prevRunEndX;
          charIndex += run.start;
          prevGlyphX = glyphX;
          prevGlyphObj = glyphObj;
          const char = text.charAt(charIndex);
          const glyphWidth = glyphObj.advanceWidth * fontSizeMult;
          const curLineCount = currentLine.count;
          let nextLine;
          if (!("isEmpty" in glyphObj)) {
            glyphObj.isWhitespace = !!char && new RegExp(lineBreakingWhiteSpace).test(char);
            glyphObj.canBreakAfter = !!char && BREAK_AFTER_CHARS.test(char);
            glyphObj.isEmpty = glyphObj.xMin === glyphObj.xMax || glyphObj.yMin === glyphObj.yMax || DEFAULT_IGNORABLE_CHARS.test(char);
          }
          if (!glyphObj.isWhitespace && !glyphObj.isEmpty) {
            renderableGlyphCount++;
          }
          if (canWrap && hasMaxWidth && !glyphObj.isWhitespace && glyphX + glyphWidth + lineXOffset > maxWidth && curLineCount) {
            if (currentLine.glyphAt(curLineCount - 1).glyphObj.canBreakAfter) {
              nextLine = new TextLine();
              lineXOffset = -glyphX;
            } else {
              for (let i4 = curLineCount; i4--; ) {
                if (i4 === 0 && overflowWrap === "break-word") {
                  nextLine = new TextLine();
                  lineXOffset = -glyphX;
                  break;
                } else if (currentLine.glyphAt(i4).glyphObj.canBreakAfter) {
                  nextLine = currentLine.splitAt(i4 + 1);
                  const adjustX = nextLine.glyphAt(0).x;
                  lineXOffset -= adjustX;
                  for (let j = nextLine.count; j--; ) {
                    nextLine.glyphAt(j).x -= adjustX;
                  }
                  break;
                }
              }
            }
            if (nextLine) {
              currentLine.isSoftWrapped = true;
              currentLine = nextLine;
              lines.push(currentLine);
              maxLineWidth = maxWidth;
            }
          }
          let fly = currentLine.glyphAt(currentLine.count);
          fly.glyphObj = glyphObj;
          fly.x = glyphX + lineXOffset;
          fly.y = glyphY;
          fly.width = glyphWidth;
          fly.charIndex = charIndex;
          fly.fontData = fontData2;
          if (char === "\n") {
            currentLine = new TextLine();
            lines.push(currentLine);
            lineXOffset = -(glyphX + glyphWidth + letterSpacing * fontSize) + textIndent;
          }
        });
        prevRunEndX = prevGlyphX + prevGlyphObj.advanceWidth * fontSizeMult + letterSpacing * fontSize;
      });
      let totalHeight = 0;
      lines.forEach((line) => {
        let isTrailingWhitespace = true;
        for (let i4 = line.count; i4--; ) {
          const glyphInfo = line.glyphAt(i4);
          if (isTrailingWhitespace && !glyphInfo.glyphObj.isWhitespace) {
            line.width = glyphInfo.x + glyphInfo.width;
            if (line.width > maxLineWidth) {
              maxLineWidth = line.width;
            }
            isTrailingWhitespace = false;
          }
          let { lineHeight: lineHeight2, capHeight, xHeight, baseline } = glyphInfo.fontData;
          if (lineHeight2 > line.lineHeight) line.lineHeight = lineHeight2;
          const baselineDiff = baseline - line.baseline;
          if (baselineDiff < 0) {
            line.baseline += baselineDiff;
            line.cap += baselineDiff;
            line.ex += baselineDiff;
          }
          line.cap = Math.max(line.cap, line.baseline + capHeight);
          line.ex = Math.max(line.ex, line.baseline + xHeight);
        }
        line.baseline -= totalHeight;
        line.cap -= totalHeight;
        line.ex -= totalHeight;
        totalHeight += line.lineHeight;
      });
      let anchorXOffset = 0;
      let anchorYOffset = 0;
      if (anchorX) {
        if (typeof anchorX === "number") {
          anchorXOffset = -anchorX;
        } else if (typeof anchorX === "string") {
          anchorXOffset = -maxLineWidth * (anchorX === "left" ? 0 : anchorX === "center" ? 0.5 : anchorX === "right" ? 1 : parsePercent(anchorX));
        }
      }
      if (anchorY) {
        if (typeof anchorY === "number") {
          anchorYOffset = -anchorY;
        } else if (typeof anchorY === "string") {
          anchorYOffset = anchorY === "top" ? 0 : anchorY === "top-baseline" ? -lines[0].baseline : anchorY === "top-cap" ? -lines[0].cap : anchorY === "top-ex" ? -lines[0].ex : anchorY === "middle" ? totalHeight / 2 : anchorY === "bottom" ? totalHeight : anchorY === "bottom-baseline" ? -lines[lines.length - 1].baseline : parsePercent(anchorY) * totalHeight;
        }
      }
      if (!metricsOnly) {
        const bidiLevelsResult = bidi.getEmbeddingLevels(text, direction2);
        glyphIds = new Uint16Array(renderableGlyphCount);
        glyphFontIndices = new Uint8Array(renderableGlyphCount);
        glyphPositions = new Float32Array(renderableGlyphCount * 2);
        glyphData = {};
        visibleBounds = [INF, INF, -INF, -INF];
        chunkedBounds = [];
        if (includeCaretPositions) {
          caretPositions = new Float32Array(text.length * 4);
        }
        if (colorRanges) {
          glyphColors = new Uint8Array(renderableGlyphCount * 3);
        }
        let renderableGlyphIndex = 0;
        let prevCharIndex = -1;
        let colorCharIndex = -1;
        let chunk;
        let currentColor;
        lines.forEach((line, lineIndex) => {
          let { count: lineGlyphCount, width: lineWidth } = line;
          if (lineGlyphCount > 0) {
            let trailingWhitespaceCount = 0;
            for (let i4 = lineGlyphCount; i4-- && line.glyphAt(i4).glyphObj.isWhitespace; ) {
              trailingWhitespaceCount++;
            }
            let lineXOffset2 = 0;
            let justifyAdjust = 0;
            if (textAlign === "center") {
              lineXOffset2 = (maxLineWidth - lineWidth) / 2;
            } else if (textAlign === "right") {
              lineXOffset2 = maxLineWidth - lineWidth;
            } else if (textAlign === "justify" && line.isSoftWrapped) {
              let whitespaceCount = 0;
              for (let i4 = lineGlyphCount - trailingWhitespaceCount; i4--; ) {
                if (line.glyphAt(i4).glyphObj.isWhitespace) {
                  whitespaceCount++;
                }
              }
              justifyAdjust = (maxLineWidth - lineWidth) / whitespaceCount;
            }
            if (justifyAdjust || lineXOffset2) {
              let justifyOffset = 0;
              for (let i4 = 0; i4 < lineGlyphCount; i4++) {
                let glyphInfo = line.glyphAt(i4);
                const glyphObj2 = glyphInfo.glyphObj;
                glyphInfo.x += lineXOffset2 + justifyOffset;
                if (justifyAdjust !== 0 && glyphObj2.isWhitespace && i4 < lineGlyphCount - trailingWhitespaceCount) {
                  justifyOffset += justifyAdjust;
                  glyphInfo.width += justifyAdjust;
                }
              }
            }
            const flips = bidi.getReorderSegments(
              text,
              bidiLevelsResult,
              line.glyphAt(0).charIndex,
              line.glyphAt(line.count - 1).charIndex
            );
            for (let fi = 0; fi < flips.length; fi++) {
              const [start2, end] = flips[fi];
              let left = Infinity, right = -Infinity;
              for (let i4 = 0; i4 < lineGlyphCount; i4++) {
                if (line.glyphAt(i4).charIndex >= start2) {
                  let startInLine = i4, endInLine = i4;
                  for (; endInLine < lineGlyphCount; endInLine++) {
                    let info = line.glyphAt(endInLine);
                    if (info.charIndex > end) {
                      break;
                    }
                    if (endInLine < lineGlyphCount - trailingWhitespaceCount) {
                      left = Math.min(left, info.x);
                      right = Math.max(right, info.x + info.width);
                    }
                  }
                  for (let j = startInLine; j < endInLine; j++) {
                    const glyphInfo = line.glyphAt(j);
                    glyphInfo.x = right - (glyphInfo.x + glyphInfo.width - left);
                  }
                  break;
                }
              }
            }
            let glyphObj;
            const setGlyphObj = (g) => glyphObj = g;
            for (let i4 = 0; i4 < lineGlyphCount; i4++) {
              const glyphInfo = line.glyphAt(i4);
              glyphObj = glyphInfo.glyphObj;
              const glyphId = glyphObj.index;
              const rtl = bidiLevelsResult.levels[glyphInfo.charIndex] & 1;
              if (rtl) {
                const mirrored = bidi.getMirroredCharacter(text[glyphInfo.charIndex]);
                if (mirrored) {
                  glyphInfo.fontData.fontObj.forEachGlyph(mirrored, 0, 0, setGlyphObj);
                }
              }
              if (includeCaretPositions) {
                const { charIndex, fontData: fontData2 } = glyphInfo;
                const caretLeft = glyphInfo.x + anchorXOffset;
                const caretRight = glyphInfo.x + glyphInfo.width + anchorXOffset;
                caretPositions[charIndex * 4] = rtl ? caretRight : caretLeft;
                caretPositions[charIndex * 4 + 1] = rtl ? caretLeft : caretRight;
                caretPositions[charIndex * 4 + 2] = line.baseline + fontData2.caretBottom + anchorYOffset;
                caretPositions[charIndex * 4 + 3] = line.baseline + fontData2.caretTop + anchorYOffset;
                const ligCount = charIndex - prevCharIndex;
                if (ligCount > 1) {
                  fillLigatureCaretPositions(caretPositions, prevCharIndex, ligCount);
                }
                prevCharIndex = charIndex;
              }
              if (colorRanges) {
                const { charIndex } = glyphInfo;
                while (charIndex > colorCharIndex) {
                  colorCharIndex++;
                  if (colorRanges.hasOwnProperty(colorCharIndex)) {
                    currentColor = colorRanges[colorCharIndex];
                  }
                }
              }
              if (!glyphObj.isWhitespace && !glyphObj.isEmpty) {
                const idx = renderableGlyphIndex++;
                const { fontSizeMult, src: fontSrc, index: fontIndex } = glyphInfo.fontData;
                const fontGlyphData = glyphData[fontSrc] || (glyphData[fontSrc] = {});
                if (!fontGlyphData[glyphId]) {
                  fontGlyphData[glyphId] = {
                    path: glyphObj.path,
                    pathBounds: [glyphObj.xMin, glyphObj.yMin, glyphObj.xMax, glyphObj.yMax]
                  };
                }
                const glyphX = glyphInfo.x + anchorXOffset;
                const glyphY = glyphInfo.y + line.baseline + anchorYOffset;
                glyphPositions[idx * 2] = glyphX;
                glyphPositions[idx * 2 + 1] = glyphY;
                const visX0 = glyphX + glyphObj.xMin * fontSizeMult;
                const visY0 = glyphY + glyphObj.yMin * fontSizeMult;
                const visX1 = glyphX + glyphObj.xMax * fontSizeMult;
                const visY1 = glyphY + glyphObj.yMax * fontSizeMult;
                if (visX0 < visibleBounds[0]) visibleBounds[0] = visX0;
                if (visY0 < visibleBounds[1]) visibleBounds[1] = visY0;
                if (visX1 > visibleBounds[2]) visibleBounds[2] = visX1;
                if (visY1 > visibleBounds[3]) visibleBounds[3] = visY1;
                if (idx % chunkedBoundsSize === 0) {
                  chunk = { start: idx, end: idx, rect: [INF, INF, -INF, -INF] };
                  chunkedBounds.push(chunk);
                }
                chunk.end++;
                const chunkRect = chunk.rect;
                if (visX0 < chunkRect[0]) chunkRect[0] = visX0;
                if (visY0 < chunkRect[1]) chunkRect[1] = visY0;
                if (visX1 > chunkRect[2]) chunkRect[2] = visX1;
                if (visY1 > chunkRect[3]) chunkRect[3] = visY1;
                glyphIds[idx] = glyphId;
                glyphFontIndices[idx] = fontIndex;
                if (colorRanges) {
                  const start2 = idx * 3;
                  glyphColors[start2] = currentColor >> 16 & 255;
                  glyphColors[start2 + 1] = currentColor >> 8 & 255;
                  glyphColors[start2 + 2] = currentColor & 255;
                }
              }
            }
          }
        });
        if (caretPositions) {
          const ligCount = text.length - prevCharIndex;
          if (ligCount > 1) {
            fillLigatureCaretPositions(caretPositions, prevCharIndex, ligCount);
          }
        }
      }
      const fontData = [];
      metricsByFont.forEach(({ index: index2, src, unitsPerEm, ascender, descender, lineHeight: lineHeight2, capHeight, xHeight }) => {
        fontData[index2] = { src, unitsPerEm, ascender, descender, lineHeight: lineHeight2, capHeight, xHeight };
      });
      timings.typesetting = now2() - typesetStart;
      callback({
        glyphIds,
        //id for each glyph, specific to that glyph's font
        glyphFontIndices,
        //index into fontData for each glyph
        glyphPositions,
        //x,y of each glyph's origin in layout
        glyphData,
        //dict holding data about each glyph appearing in the text
        fontData,
        //data about each font used in the text
        caretPositions,
        //startX,endX,bottomY caret positions for each char
        // caretHeight, //height of cursor from bottom to top - todo per glyph?
        glyphColors,
        //color for each glyph, if color ranges supplied
        chunkedBounds,
        //total rects per (n=chunkedBoundsSize) consecutive glyphs
        fontSize,
        //calculated em height
        topBaseline: anchorYOffset + lines[0].baseline,
        //y coordinate of the top line's baseline
        blockBounds: [
          //bounds for the whole block of text, including vertical padding for lineHeight
          anchorXOffset,
          anchorYOffset - totalHeight,
          anchorXOffset + maxLineWidth,
          anchorYOffset
        ],
        visibleBounds,
        //total bounds of visible text paths, may be larger or smaller than blockBounds
        timings
      });
    });
  }
  function measure(args, callback) {
    typeset({ ...args, metricsOnly: true }, (result) => {
      const [x0, y0, x1, y1] = result.blockBounds;
      callback({
        width: x1 - x0,
        height: y1 - y0
      });
    });
  }
  function parsePercent(str) {
    let match = str.match(/^([\d.]+)%$/);
    let pct = match ? parseFloat(match[1]) : NaN;
    return isNaN(pct) ? 0 : pct / 100;
  }
  function fillLigatureCaretPositions(caretPositions, ligStartIndex, ligCount) {
    const ligStartX = caretPositions[ligStartIndex * 4];
    const ligEndX = caretPositions[ligStartIndex * 4 + 1];
    const ligBottom = caretPositions[ligStartIndex * 4 + 2];
    const ligTop = caretPositions[ligStartIndex * 4 + 3];
    const guessedAdvanceX = (ligEndX - ligStartX) / ligCount;
    for (let i4 = 0; i4 < ligCount; i4++) {
      const startIndex = (ligStartIndex + i4) * 4;
      caretPositions[startIndex] = ligStartX + guessedAdvanceX * i4;
      caretPositions[startIndex + 1] = ligStartX + guessedAdvanceX * (i4 + 1);
      caretPositions[startIndex + 2] = ligBottom;
      caretPositions[startIndex + 3] = ligTop;
    }
  }
  function now2() {
    return (self.performance || Date).now();
  }
  function TextLine() {
    this.data = [];
  }
  const textLineProps = ["glyphObj", "x", "y", "width", "charIndex", "fontData"];
  TextLine.prototype = {
    width: 0,
    lineHeight: 0,
    baseline: 0,
    cap: 0,
    ex: 0,
    isSoftWrapped: false,
    get count() {
      return Math.ceil(this.data.length / textLineProps.length);
    },
    glyphAt(i4) {
      let fly = TextLine.flyweight;
      fly.data = this.data;
      fly.index = i4;
      return fly;
    },
    splitAt(i4) {
      let newLine = new TextLine();
      newLine.data = this.data.splice(i4 * textLineProps.length);
      return newLine;
    }
  };
  TextLine.flyweight = textLineProps.reduce((obj, prop, i4, all) => {
    Object.defineProperty(obj, prop, {
      get() {
        return this.data[this.index * textLineProps.length + i4];
      },
      set(val) {
        this.data[this.index * textLineProps.length + i4] = val;
      }
    });
    return obj;
  }, { data: null, index: 0 });
  return {
    typeset,
    measure
  };
}
)}
)
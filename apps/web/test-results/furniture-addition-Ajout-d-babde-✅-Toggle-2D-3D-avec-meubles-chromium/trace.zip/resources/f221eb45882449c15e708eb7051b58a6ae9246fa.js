/** <Typesetter>.init **/

troikaDefine(
function init(createTypesetter2, fontResolver, bidiFactory2) {
    return createTypesetter2(fontResolver, bidiFactory2());
  }
)
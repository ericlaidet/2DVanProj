/** <<Typr Font Parser> function dependency: typrFactory>.init **/

troikaDefine(
function(){return (
function typrFactory() {
  return "undefined" == typeof window && (self.window = self), function(r2) {
    var e2 = { parse: function(r3) {
      var t4 = e2._bin, a7 = new Uint8Array(r3);
      if ("ttcf" == t4.readASCII(a7, 0, 4)) {
        var n2 = 4;
        t4.readUshort(a7, n2), n2 += 2, t4.readUshort(a7, n2), n2 += 2;
        var o2 = t4.readUint(a7, n2);
        n2 += 4;
        for (var s2 = [], i4 = 0; i4 < o2; i4++) {
          var h = t4.readUint(a7, n2);
          n2 += 4, s2.push(e2._readFont(a7, h));
        }
        return s2;
      }
      return [e2._readFont(a7, 0)];
    }, _readFont: function(r3, t4) {
      var a7 = e2._bin, n2 = t4;
      a7.readFixed(r3, t4), t4 += 4;
      var o2 = a7.readUshort(r3, t4);
      t4 += 2, a7.readUshort(r3, t4), t4 += 2, a7.readUshort(r3, t4), t4 += 2, a7.readUshort(r3, t4), t4 += 2;
      for (var s2 = ["cmap", "head", "hhea", "maxp", "hmtx", "name", "OS/2", "post", "loca", "glyf", "kern", "CFF ", "GDEF", "GPOS", "GSUB", "SVG "], i4 = { _data: r3, _offset: n2 }, h = {}, d2 = 0; d2 < o2; d2++) {
        var f2 = a7.readASCII(r3, t4, 4);
        t4 += 4, a7.readUint(r3, t4), t4 += 4;
        var u = a7.readUint(r3, t4);
        t4 += 4;
        var l2 = a7.readUint(r3, t4);
        t4 += 4, h[f2] = { offset: u, length: l2 };
      }
      for (d2 = 0; d2 < s2.length; d2++) {
        var v5 = s2[d2];
        h[v5] && (i4[v5.trim()] = e2[v5.trim()].parse(r3, h[v5].offset, h[v5].length, i4));
      }
      return i4;
    }, _tabOffset: function(r3, t4, a7) {
      for (var n2 = e2._bin, o2 = n2.readUshort(r3, a7 + 4), s2 = a7 + 12, i4 = 0; i4 < o2; i4++) {
        var h = n2.readASCII(r3, s2, 4);
        s2 += 4, n2.readUint(r3, s2), s2 += 4;
        var d2 = n2.readUint(r3, s2);
        if (s2 += 4, n2.readUint(r3, s2), s2 += 4, h == t4) return d2;
      }
      return 0;
    } };
    e2._bin = { readFixed: function(r3, e3) {
      return (r3[e3] << 8 | r3[e3 + 1]) + (r3[e3 + 2] << 8 | r3[e3 + 3]) / 65540;
    }, readF2dot14: function(r3, t4) {
      return e2._bin.readShort(r3, t4) / 16384;
    }, readInt: function(r3, t4) {
      return e2._bin._view(r3).getInt32(t4);
    }, readInt8: function(r3, t4) {
      return e2._bin._view(r3).getInt8(t4);
    }, readShort: function(r3, t4) {
      return e2._bin._view(r3).getInt16(t4);
    }, readUshort: function(r3, t4) {
      return e2._bin._view(r3).getUint16(t4);
    }, readUshorts: function(r3, t4, a7) {
      for (var n2 = [], o2 = 0; o2 < a7; o2++) n2.push(e2._bin.readUshort(r3, t4 + 2 * o2));
      return n2;
    }, readUint: function(r3, t4) {
      return e2._bin._view(r3).getUint32(t4);
    }, readUint64: function(r3, t4) {
      return 4294967296 * e2._bin.readUint(r3, t4) + e2._bin.readUint(r3, t4 + 4);
    }, readASCII: function(r3, e3, t4) {
      for (var a7 = "", n2 = 0; n2 < t4; n2++) a7 += String.fromCharCode(r3[e3 + n2]);
      return a7;
    }, readUnicode: function(r3, e3, t4) {
      for (var a7 = "", n2 = 0; n2 < t4; n2++) {
        var o2 = r3[e3++] << 8 | r3[e3++];
        a7 += String.fromCharCode(o2);
      }
      return a7;
    }, _tdec: "undefined" != typeof window && window.TextDecoder ? new window.TextDecoder() : null, readUTF8: function(r3, t4, a7) {
      var n2 = e2._bin._tdec;
      return n2 && 0 == t4 && a7 == r3.length ? n2.decode(r3) : e2._bin.readASCII(r3, t4, a7);
    }, readBytes: function(r3, e3, t4) {
      for (var a7 = [], n2 = 0; n2 < t4; n2++) a7.push(r3[e3 + n2]);
      return a7;
    }, readASCIIArray: function(r3, e3, t4) {
      for (var a7 = [], n2 = 0; n2 < t4; n2++) a7.push(String.fromCharCode(r3[e3 + n2]));
      return a7;
    }, _view: function(r3) {
      return r3._dataView || (r3._dataView = r3.buffer ? new DataView(r3.buffer, r3.byteOffset, r3.byteLength) : new DataView(new Uint8Array(r3).buffer));
    } }, e2._lctf = {}, e2._lctf.parse = function(r3, t4, a7, n2, o2) {
      var s2 = e2._bin, i4 = {}, h = t4;
      s2.readFixed(r3, t4), t4 += 4;
      var d2 = s2.readUshort(r3, t4);
      t4 += 2;
      var f2 = s2.readUshort(r3, t4);
      t4 += 2;
      var u = s2.readUshort(r3, t4);
      return t4 += 2, i4.scriptList = e2._lctf.readScriptList(r3, h + d2), i4.featureList = e2._lctf.readFeatureList(r3, h + f2), i4.lookupList = e2._lctf.readLookupList(r3, h + u, o2), i4;
    }, e2._lctf.readLookupList = function(r3, t4, a7) {
      var n2 = e2._bin, o2 = t4, s2 = [], i4 = n2.readUshort(r3, t4);
      t4 += 2;
      for (var h = 0; h < i4; h++) {
        var d2 = n2.readUshort(r3, t4);
        t4 += 2;
        var f2 = e2._lctf.readLookupTable(r3, o2 + d2, a7);
        s2.push(f2);
      }
      return s2;
    }, e2._lctf.readLookupTable = function(r3, t4, a7) {
      var n2 = e2._bin, o2 = t4, s2 = { tabs: [] };
      s2.ltype = n2.readUshort(r3, t4), t4 += 2, s2.flag = n2.readUshort(r3, t4), t4 += 2;
      var i4 = n2.readUshort(r3, t4);
      t4 += 2;
      for (var h = s2.ltype, d2 = 0; d2 < i4; d2++) {
        var f2 = n2.readUshort(r3, t4);
        t4 += 2;
        var u = a7(r3, h, o2 + f2, s2);
        s2.tabs.push(u);
      }
      return s2;
    }, e2._lctf.numOfOnes = function(r3) {
      for (var e3 = 0, t4 = 0; t4 < 32; t4++) 0 != (r3 >>> t4 & 1) && e3++;
      return e3;
    }, e2._lctf.readClassDef = function(r3, t4) {
      var a7 = e2._bin, n2 = [], o2 = a7.readUshort(r3, t4);
      if (t4 += 2, 1 == o2) {
        var s2 = a7.readUshort(r3, t4);
        t4 += 2;
        var i4 = a7.readUshort(r3, t4);
        t4 += 2;
        for (var h = 0; h < i4; h++) n2.push(s2 + h), n2.push(s2 + h), n2.push(a7.readUshort(r3, t4)), t4 += 2;
      }
      if (2 == o2) {
        var d2 = a7.readUshort(r3, t4);
        t4 += 2;
        for (h = 0; h < d2; h++) n2.push(a7.readUshort(r3, t4)), t4 += 2, n2.push(a7.readUshort(r3, t4)), t4 += 2, n2.push(a7.readUshort(r3, t4)), t4 += 2;
      }
      return n2;
    }, e2._lctf.getInterval = function(r3, e3) {
      for (var t4 = 0; t4 < r3.length; t4 += 3) {
        var a7 = r3[t4], n2 = r3[t4 + 1];
        if (r3[t4 + 2], a7 <= e3 && e3 <= n2) return t4;
      }
      return -1;
    }, e2._lctf.readCoverage = function(r3, t4) {
      var a7 = e2._bin, n2 = {};
      n2.fmt = a7.readUshort(r3, t4), t4 += 2;
      var o2 = a7.readUshort(r3, t4);
      return t4 += 2, 1 == n2.fmt && (n2.tab = a7.readUshorts(r3, t4, o2)), 2 == n2.fmt && (n2.tab = a7.readUshorts(r3, t4, 3 * o2)), n2;
    }, e2._lctf.coverageIndex = function(r3, t4) {
      var a7 = r3.tab;
      if (1 == r3.fmt) return a7.indexOf(t4);
      if (2 == r3.fmt) {
        var n2 = e2._lctf.getInterval(a7, t4);
        if (-1 != n2) return a7[n2 + 2] + (t4 - a7[n2]);
      }
      return -1;
    }, e2._lctf.readFeatureList = function(r3, t4) {
      var a7 = e2._bin, n2 = t4, o2 = [], s2 = a7.readUshort(r3, t4);
      t4 += 2;
      for (var i4 = 0; i4 < s2; i4++) {
        var h = a7.readASCII(r3, t4, 4);
        t4 += 4;
        var d2 = a7.readUshort(r3, t4);
        t4 += 2;
        var f2 = e2._lctf.readFeatureTable(r3, n2 + d2);
        f2.tag = h.trim(), o2.push(f2);
      }
      return o2;
    }, e2._lctf.readFeatureTable = function(r3, t4) {
      var a7 = e2._bin, n2 = t4, o2 = {}, s2 = a7.readUshort(r3, t4);
      t4 += 2, s2 > 0 && (o2.featureParams = n2 + s2);
      var i4 = a7.readUshort(r3, t4);
      t4 += 2, o2.tab = [];
      for (var h = 0; h < i4; h++) o2.tab.push(a7.readUshort(r3, t4 + 2 * h));
      return o2;
    }, e2._lctf.readScriptList = function(r3, t4) {
      var a7 = e2._bin, n2 = t4, o2 = {}, s2 = a7.readUshort(r3, t4);
      t4 += 2;
      for (var i4 = 0; i4 < s2; i4++) {
        var h = a7.readASCII(r3, t4, 4);
        t4 += 4;
        var d2 = a7.readUshort(r3, t4);
        t4 += 2, o2[h.trim()] = e2._lctf.readScriptTable(r3, n2 + d2);
      }
      return o2;
    }, e2._lctf.readScriptTable = function(r3, t4) {
      var a7 = e2._bin, n2 = t4, o2 = {}, s2 = a7.readUshort(r3, t4);
      t4 += 2, s2 > 0 && (o2.default = e2._lctf.readLangSysTable(r3, n2 + s2));
      var i4 = a7.readUshort(r3, t4);
      t4 += 2;
      for (var h = 0; h < i4; h++) {
        var d2 = a7.readASCII(r3, t4, 4);
        t4 += 4;
        var f2 = a7.readUshort(r3, t4);
        t4 += 2, o2[d2.trim()] = e2._lctf.readLangSysTable(r3, n2 + f2);
      }
      return o2;
    }, e2._lctf.readLangSysTable = function(r3, t4) {
      var a7 = e2._bin, n2 = {};
      a7.readUshort(r3, t4), t4 += 2, n2.reqFeature = a7.readUshort(r3, t4), t4 += 2;
      var o2 = a7.readUshort(r3, t4);
      return t4 += 2, n2.features = a7.readUshorts(r3, t4, o2), n2;
    }, e2.CFF = {}, e2.CFF.parse = function(r3, t4, a7) {
      var n2 = e2._bin;
      (r3 = new Uint8Array(r3.buffer, t4, a7))[t4 = 0], r3[++t4], r3[++t4], r3[++t4], t4++;
      var o2 = [];
      t4 = e2.CFF.readIndex(r3, t4, o2);
      for (var s2 = [], i4 = 0; i4 < o2.length - 1; i4++) s2.push(n2.readASCII(r3, t4 + o2[i4], o2[i4 + 1] - o2[i4]));
      t4 += o2[o2.length - 1];
      var h = [];
      t4 = e2.CFF.readIndex(r3, t4, h);
      var d2 = [];
      for (i4 = 0; i4 < h.length - 1; i4++) d2.push(e2.CFF.readDict(r3, t4 + h[i4], t4 + h[i4 + 1]));
      t4 += h[h.length - 1];
      var f2 = d2[0], u = [];
      t4 = e2.CFF.readIndex(r3, t4, u);
      var l2 = [];
      for (i4 = 0; i4 < u.length - 1; i4++) l2.push(n2.readASCII(r3, t4 + u[i4], u[i4 + 1] - u[i4]));
      if (t4 += u[u.length - 1], e2.CFF.readSubrs(r3, t4, f2), f2.CharStrings) {
        t4 = f2.CharStrings;
        u = [];
        t4 = e2.CFF.readIndex(r3, t4, u);
        var v5 = [];
        for (i4 = 0; i4 < u.length - 1; i4++) v5.push(n2.readBytes(r3, t4 + u[i4], u[i4 + 1] - u[i4]));
        f2.CharStrings = v5;
      }
      if (f2.ROS) {
        t4 = f2.FDArray;
        var c6 = [];
        t4 = e2.CFF.readIndex(r3, t4, c6), f2.FDArray = [];
        for (i4 = 0; i4 < c6.length - 1; i4++) {
          var p2 = e2.CFF.readDict(r3, t4 + c6[i4], t4 + c6[i4 + 1]);
          e2.CFF._readFDict(r3, p2, l2), f2.FDArray.push(p2);
        }
        t4 += c6[c6.length - 1], t4 = f2.FDSelect, f2.FDSelect = [];
        var U = r3[t4];
        if (t4++, 3 != U) throw U;
        var g = n2.readUshort(r3, t4);
        t4 += 2;
        for (i4 = 0; i4 < g + 1; i4++) f2.FDSelect.push(n2.readUshort(r3, t4), r3[t4 + 2]), t4 += 3;
      }
      return f2.Encoding && (f2.Encoding = e2.CFF.readEncoding(r3, f2.Encoding, f2.CharStrings.length)), f2.charset && (f2.charset = e2.CFF.readCharset(r3, f2.charset, f2.CharStrings.length)), e2.CFF._readFDict(r3, f2, l2), f2;
    }, e2.CFF._readFDict = function(r3, t4, a7) {
      var n2;
      for (var o2 in t4.Private && (n2 = t4.Private[1], t4.Private = e2.CFF.readDict(r3, n2, n2 + t4.Private[0]), t4.Private.Subrs && e2.CFF.readSubrs(r3, n2 + t4.Private.Subrs, t4.Private)), t4) -1 != ["FamilyName", "FontName", "FullName", "Notice", "version", "Copyright"].indexOf(o2) && (t4[o2] = a7[t4[o2] - 426 + 35]);
    }, e2.CFF.readSubrs = function(r3, t4, a7) {
      var n2 = e2._bin, o2 = [];
      t4 = e2.CFF.readIndex(r3, t4, o2);
      var s2, i4 = o2.length;
      s2 = i4 < 1240 ? 107 : i4 < 33900 ? 1131 : 32768, a7.Bias = s2, a7.Subrs = [];
      for (var h = 0; h < o2.length - 1; h++) a7.Subrs.push(n2.readBytes(r3, t4 + o2[h], o2[h + 1] - o2[h]));
    }, e2.CFF.tableSE = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 0, 111, 112, 113, 114, 0, 115, 116, 117, 118, 119, 120, 121, 122, 0, 123, 0, 124, 125, 126, 127, 128, 129, 130, 131, 0, 132, 133, 0, 134, 135, 136, 137, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 138, 0, 139, 0, 0, 0, 0, 140, 141, 142, 143, 0, 0, 0, 0, 0, 144, 0, 0, 0, 145, 0, 0, 146, 147, 148, 149, 0, 0, 0, 0], e2.CFF.glyphByUnicode = function(r3, e3) {
      for (var t4 = 0; t4 < r3.charset.length; t4++) if (r3.charset[t4] == e3) return t4;
      return -1;
    }, e2.CFF.glyphBySE = function(r3, t4) {
      return t4 < 0 || t4 > 255 ? -1 : e2.CFF.glyphByUnicode(r3, e2.CFF.tableSE[t4]);
    }, e2.CFF.readEncoding = function(r3, t4, a7) {
      e2._bin;
      var n2 = [".notdef"], o2 = r3[t4];
      if (t4++, 0 != o2) throw "error: unknown encoding format: " + o2;
      var s2 = r3[t4];
      t4++;
      for (var i4 = 0; i4 < s2; i4++) n2.push(r3[t4 + i4]);
      return n2;
    }, e2.CFF.readCharset = function(r3, t4, a7) {
      var n2 = e2._bin, o2 = [".notdef"], s2 = r3[t4];
      if (t4++, 0 == s2) for (var i4 = 0; i4 < a7; i4++) {
        var h = n2.readUshort(r3, t4);
        t4 += 2, o2.push(h);
      }
      else {
        if (1 != s2 && 2 != s2) throw "error: format: " + s2;
        for (; o2.length < a7; ) {
          h = n2.readUshort(r3, t4);
          t4 += 2;
          var d2 = 0;
          1 == s2 ? (d2 = r3[t4], t4++) : (d2 = n2.readUshort(r3, t4), t4 += 2);
          for (i4 = 0; i4 <= d2; i4++) o2.push(h), h++;
        }
      }
      return o2;
    }, e2.CFF.readIndex = function(r3, t4, a7) {
      var n2 = e2._bin, o2 = n2.readUshort(r3, t4) + 1, s2 = r3[t4 += 2];
      if (t4++, 1 == s2) for (var i4 = 0; i4 < o2; i4++) a7.push(r3[t4 + i4]);
      else if (2 == s2) for (i4 = 0; i4 < o2; i4++) a7.push(n2.readUshort(r3, t4 + 2 * i4));
      else if (3 == s2) for (i4 = 0; i4 < o2; i4++) a7.push(16777215 & n2.readUint(r3, t4 + 3 * i4 - 1));
      else if (1 != o2) throw "unsupported offset size: " + s2 + ", count: " + o2;
      return (t4 += o2 * s2) - 1;
    }, e2.CFF.getCharString = function(r3, t4, a7) {
      var n2 = e2._bin, o2 = r3[t4], s2 = r3[t4 + 1];
      r3[t4 + 2], r3[t4 + 3], r3[t4 + 4];
      var i4 = 1, h = null, d2 = null;
      o2 <= 20 && (h = o2, i4 = 1), 12 == o2 && (h = 100 * o2 + s2, i4 = 2), 21 <= o2 && o2 <= 27 && (h = o2, i4 = 1), 28 == o2 && (d2 = n2.readShort(r3, t4 + 1), i4 = 3), 29 <= o2 && o2 <= 31 && (h = o2, i4 = 1), 32 <= o2 && o2 <= 246 && (d2 = o2 - 139, i4 = 1), 247 <= o2 && o2 <= 250 && (d2 = 256 * (o2 - 247) + s2 + 108, i4 = 2), 251 <= o2 && o2 <= 254 && (d2 = 256 * -(o2 - 251) - s2 - 108, i4 = 2), 255 == o2 && (d2 = n2.readInt(r3, t4 + 1) / 65535, i4 = 5), a7.val = null != d2 ? d2 : "o" + h, a7.size = i4;
    }, e2.CFF.readCharString = function(r3, t4, a7) {
      for (var n2 = t4 + a7, o2 = e2._bin, s2 = []; t4 < n2; ) {
        var i4 = r3[t4], h = r3[t4 + 1];
        r3[t4 + 2], r3[t4 + 3], r3[t4 + 4];
        var d2 = 1, f2 = null, u = null;
        i4 <= 20 && (f2 = i4, d2 = 1), 12 == i4 && (f2 = 100 * i4 + h, d2 = 2), 19 != i4 && 20 != i4 || (f2 = i4, d2 = 2), 21 <= i4 && i4 <= 27 && (f2 = i4, d2 = 1), 28 == i4 && (u = o2.readShort(r3, t4 + 1), d2 = 3), 29 <= i4 && i4 <= 31 && (f2 = i4, d2 = 1), 32 <= i4 && i4 <= 246 && (u = i4 - 139, d2 = 1), 247 <= i4 && i4 <= 250 && (u = 256 * (i4 - 247) + h + 108, d2 = 2), 251 <= i4 && i4 <= 254 && (u = 256 * -(i4 - 251) - h - 108, d2 = 2), 255 == i4 && (u = o2.readInt(r3, t4 + 1) / 65535, d2 = 5), s2.push(null != u ? u : "o" + f2), t4 += d2;
      }
      return s2;
    }, e2.CFF.readDict = function(r3, t4, a7) {
      for (var n2 = e2._bin, o2 = {}, s2 = []; t4 < a7; ) {
        var i4 = r3[t4], h = r3[t4 + 1];
        r3[t4 + 2], r3[t4 + 3], r3[t4 + 4];
        var d2 = 1, f2 = null, u = null;
        if (28 == i4 && (u = n2.readShort(r3, t4 + 1), d2 = 3), 29 == i4 && (u = n2.readInt(r3, t4 + 1), d2 = 5), 32 <= i4 && i4 <= 246 && (u = i4 - 139, d2 = 1), 247 <= i4 && i4 <= 250 && (u = 256 * (i4 - 247) + h + 108, d2 = 2), 251 <= i4 && i4 <= 254 && (u = 256 * -(i4 - 251) - h - 108, d2 = 2), 255 == i4) throw u = n2.readInt(r3, t4 + 1) / 65535, d2 = 5, "unknown number";
        if (30 == i4) {
          var l2 = [];
          for (d2 = 1; ; ) {
            var v5 = r3[t4 + d2];
            d2++;
            var c6 = v5 >> 4, p2 = 15 & v5;
            if (15 != c6 && l2.push(c6), 15 != p2 && l2.push(p2), 15 == p2) break;
          }
          for (var U = "", g = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, ".", "e", "e-", "reserved", "-", "endOfNumber"], S = 0; S < l2.length; S++) U += g[l2[S]];
          u = parseFloat(U);
        }
        if (i4 <= 21) {
          if (f2 = ["version", "Notice", "FullName", "FamilyName", "Weight", "FontBBox", "BlueValues", "OtherBlues", "FamilyBlues", "FamilyOtherBlues", "StdHW", "StdVW", "escape", "UniqueID", "XUID", "charset", "Encoding", "CharStrings", "Private", "Subrs", "defaultWidthX", "nominalWidthX"][i4], d2 = 1, 12 == i4) f2 = ["Copyright", "isFixedPitch", "ItalicAngle", "UnderlinePosition", "UnderlineThickness", "PaintType", "CharstringType", "FontMatrix", "StrokeWidth", "BlueScale", "BlueShift", "BlueFuzz", "StemSnapH", "StemSnapV", "ForceBold", 0, 0, "LanguageGroup", "ExpansionFactor", "initialRandomSeed", "SyntheticBase", "PostScript", "BaseFontName", "BaseFontBlend", 0, 0, 0, 0, 0, 0, "ROS", "CIDFontVersion", "CIDFontRevision", "CIDFontType", "CIDCount", "UIDBase", "FDArray", "FDSelect", "FontName"][h], d2 = 2;
        }
        null != f2 ? (o2[f2] = 1 == s2.length ? s2[0] : s2, s2 = []) : s2.push(u), t4 += d2;
      }
      return o2;
    }, e2.cmap = {}, e2.cmap.parse = function(r3, t4, a7) {
      r3 = new Uint8Array(r3.buffer, t4, a7), t4 = 0;
      var n2 = e2._bin, o2 = {};
      n2.readUshort(r3, t4), t4 += 2;
      var s2 = n2.readUshort(r3, t4);
      t4 += 2;
      var i4 = [];
      o2.tables = [];
      for (var h = 0; h < s2; h++) {
        var d2 = n2.readUshort(r3, t4);
        t4 += 2;
        var f2 = n2.readUshort(r3, t4);
        t4 += 2;
        var u = n2.readUint(r3, t4);
        t4 += 4;
        var l2 = "p" + d2 + "e" + f2, v5 = i4.indexOf(u);
        if (-1 == v5) {
          var c6;
          v5 = o2.tables.length, i4.push(u);
          var p2 = n2.readUshort(r3, u);
          0 == p2 ? c6 = e2.cmap.parse0(r3, u) : 4 == p2 ? c6 = e2.cmap.parse4(r3, u) : 6 == p2 ? c6 = e2.cmap.parse6(r3, u) : 12 == p2 ? c6 = e2.cmap.parse12(r3, u) : console.debug("unknown format: " + p2, d2, f2, u), o2.tables.push(c6);
        }
        if (null != o2[l2]) throw "multiple tables for one platform+encoding";
        o2[l2] = v5;
      }
      return o2;
    }, e2.cmap.parse0 = function(r3, t4) {
      var a7 = e2._bin, n2 = {};
      n2.format = a7.readUshort(r3, t4), t4 += 2;
      var o2 = a7.readUshort(r3, t4);
      t4 += 2, a7.readUshort(r3, t4), t4 += 2, n2.map = [];
      for (var s2 = 0; s2 < o2 - 6; s2++) n2.map.push(r3[t4 + s2]);
      return n2;
    }, e2.cmap.parse4 = function(r3, t4) {
      var a7 = e2._bin, n2 = t4, o2 = {};
      o2.format = a7.readUshort(r3, t4), t4 += 2;
      var s2 = a7.readUshort(r3, t4);
      t4 += 2, a7.readUshort(r3, t4), t4 += 2;
      var i4 = a7.readUshort(r3, t4);
      t4 += 2;
      var h = i4 / 2;
      o2.searchRange = a7.readUshort(r3, t4), t4 += 2, o2.entrySelector = a7.readUshort(r3, t4), t4 += 2, o2.rangeShift = a7.readUshort(r3, t4), t4 += 2, o2.endCount = a7.readUshorts(r3, t4, h), t4 += 2 * h, t4 += 2, o2.startCount = a7.readUshorts(r3, t4, h), t4 += 2 * h, o2.idDelta = [];
      for (var d2 = 0; d2 < h; d2++) o2.idDelta.push(a7.readShort(r3, t4)), t4 += 2;
      for (o2.idRangeOffset = a7.readUshorts(r3, t4, h), t4 += 2 * h, o2.glyphIdArray = []; t4 < n2 + s2; ) o2.glyphIdArray.push(a7.readUshort(r3, t4)), t4 += 2;
      return o2;
    }, e2.cmap.parse6 = function(r3, t4) {
      var a7 = e2._bin, n2 = {};
      n2.format = a7.readUshort(r3, t4), t4 += 2, a7.readUshort(r3, t4), t4 += 2, a7.readUshort(r3, t4), t4 += 2, n2.firstCode = a7.readUshort(r3, t4), t4 += 2;
      var o2 = a7.readUshort(r3, t4);
      t4 += 2, n2.glyphIdArray = [];
      for (var s2 = 0; s2 < o2; s2++) n2.glyphIdArray.push(a7.readUshort(r3, t4)), t4 += 2;
      return n2;
    }, e2.cmap.parse12 = function(r3, t4) {
      var a7 = e2._bin, n2 = {};
      n2.format = a7.readUshort(r3, t4), t4 += 2, t4 += 2, a7.readUint(r3, t4), t4 += 4, a7.readUint(r3, t4), t4 += 4;
      var o2 = a7.readUint(r3, t4);
      t4 += 4, n2.groups = [];
      for (var s2 = 0; s2 < o2; s2++) {
        var i4 = t4 + 12 * s2, h = a7.readUint(r3, i4 + 0), d2 = a7.readUint(r3, i4 + 4), f2 = a7.readUint(r3, i4 + 8);
        n2.groups.push([h, d2, f2]);
      }
      return n2;
    }, e2.glyf = {}, e2.glyf.parse = function(r3, e3, t4, a7) {
      for (var n2 = [], o2 = 0; o2 < a7.maxp.numGlyphs; o2++) n2.push(null);
      return n2;
    }, e2.glyf._parseGlyf = function(r3, t4) {
      var a7 = e2._bin, n2 = r3._data, o2 = e2._tabOffset(n2, "glyf", r3._offset) + r3.loca[t4];
      if (r3.loca[t4] == r3.loca[t4 + 1]) return null;
      var s2 = {};
      if (s2.noc = a7.readShort(n2, o2), o2 += 2, s2.xMin = a7.readShort(n2, o2), o2 += 2, s2.yMin = a7.readShort(n2, o2), o2 += 2, s2.xMax = a7.readShort(n2, o2), o2 += 2, s2.yMax = a7.readShort(n2, o2), o2 += 2, s2.xMin >= s2.xMax || s2.yMin >= s2.yMax) return null;
      if (s2.noc > 0) {
        s2.endPts = [];
        for (var i4 = 0; i4 < s2.noc; i4++) s2.endPts.push(a7.readUshort(n2, o2)), o2 += 2;
        var h = a7.readUshort(n2, o2);
        if (o2 += 2, n2.length - o2 < h) return null;
        s2.instructions = a7.readBytes(n2, o2, h), o2 += h;
        var d2 = s2.endPts[s2.noc - 1] + 1;
        s2.flags = [];
        for (i4 = 0; i4 < d2; i4++) {
          var f2 = n2[o2];
          if (o2++, s2.flags.push(f2), 0 != (8 & f2)) {
            var u = n2[o2];
            o2++;
            for (var l2 = 0; l2 < u; l2++) s2.flags.push(f2), i4++;
          }
        }
        s2.xs = [];
        for (i4 = 0; i4 < d2; i4++) {
          var v5 = 0 != (2 & s2.flags[i4]), c6 = 0 != (16 & s2.flags[i4]);
          v5 ? (s2.xs.push(c6 ? n2[o2] : -n2[o2]), o2++) : c6 ? s2.xs.push(0) : (s2.xs.push(a7.readShort(n2, o2)), o2 += 2);
        }
        s2.ys = [];
        for (i4 = 0; i4 < d2; i4++) {
          v5 = 0 != (4 & s2.flags[i4]), c6 = 0 != (32 & s2.flags[i4]);
          v5 ? (s2.ys.push(c6 ? n2[o2] : -n2[o2]), o2++) : c6 ? s2.ys.push(0) : (s2.ys.push(a7.readShort(n2, o2)), o2 += 2);
        }
        var p2 = 0, U = 0;
        for (i4 = 0; i4 < d2; i4++) p2 += s2.xs[i4], U += s2.ys[i4], s2.xs[i4] = p2, s2.ys[i4] = U;
      } else {
        var g;
        s2.parts = [];
        do {
          g = a7.readUshort(n2, o2), o2 += 2;
          var S = { m: { a: 1, b: 0, c: 0, d: 1, tx: 0, ty: 0 }, p1: -1, p2: -1 };
          if (s2.parts.push(S), S.glyphIndex = a7.readUshort(n2, o2), o2 += 2, 1 & g) {
            var m = a7.readShort(n2, o2);
            o2 += 2;
            var b5 = a7.readShort(n2, o2);
            o2 += 2;
          } else {
            m = a7.readInt8(n2, o2);
            o2++;
            b5 = a7.readInt8(n2, o2);
            o2++;
          }
          2 & g ? (S.m.tx = m, S.m.ty = b5) : (S.p1 = m, S.p2 = b5), 8 & g ? (S.m.a = S.m.d = a7.readF2dot14(n2, o2), o2 += 2) : 64 & g ? (S.m.a = a7.readF2dot14(n2, o2), o2 += 2, S.m.d = a7.readF2dot14(n2, o2), o2 += 2) : 128 & g && (S.m.a = a7.readF2dot14(n2, o2), o2 += 2, S.m.b = a7.readF2dot14(n2, o2), o2 += 2, S.m.c = a7.readF2dot14(n2, o2), o2 += 2, S.m.d = a7.readF2dot14(n2, o2), o2 += 2);
        } while (32 & g);
        if (256 & g) {
          var y = a7.readUshort(n2, o2);
          o2 += 2, s2.instr = [];
          for (i4 = 0; i4 < y; i4++) s2.instr.push(n2[o2]), o2++;
        }
      }
      return s2;
    }, e2.GDEF = {}, e2.GDEF.parse = function(r3, t4, a7, n2) {
      var o2 = t4;
      t4 += 4;
      var s2 = e2._bin.readUshort(r3, t4);
      return { glyphClassDef: 0 === s2 ? null : e2._lctf.readClassDef(r3, o2 + s2) };
    }, e2.GPOS = {}, e2.GPOS.parse = function(r3, t4, a7, n2) {
      return e2._lctf.parse(r3, t4, a7, n2, e2.GPOS.subt);
    }, e2.GPOS.subt = function(r3, t4, a7, n2) {
      var o2 = e2._bin, s2 = a7, i4 = {};
      if (i4.fmt = o2.readUshort(r3, a7), a7 += 2, 1 == t4 || 2 == t4 || 3 == t4 || 7 == t4 || 8 == t4 && i4.fmt <= 2) {
        var h = o2.readUshort(r3, a7);
        a7 += 2, i4.coverage = e2._lctf.readCoverage(r3, h + s2);
      }
      if (1 == t4 && 1 == i4.fmt) {
        var d2 = o2.readUshort(r3, a7);
        a7 += 2, 0 != d2 && (i4.pos = e2.GPOS.readValueRecord(r3, a7, d2));
      } else if (2 == t4 && i4.fmt >= 1 && i4.fmt <= 2) {
        d2 = o2.readUshort(r3, a7);
        a7 += 2;
        var f2 = o2.readUshort(r3, a7);
        a7 += 2;
        var u = e2._lctf.numOfOnes(d2), l2 = e2._lctf.numOfOnes(f2);
        if (1 == i4.fmt) {
          i4.pairsets = [];
          var v5 = o2.readUshort(r3, a7);
          a7 += 2;
          for (var c6 = 0; c6 < v5; c6++) {
            var p2 = s2 + o2.readUshort(r3, a7);
            a7 += 2;
            var U = o2.readUshort(r3, p2);
            p2 += 2;
            for (var g = [], S = 0; S < U; S++) {
              var m = o2.readUshort(r3, p2);
              p2 += 2, 0 != d2 && (P = e2.GPOS.readValueRecord(r3, p2, d2), p2 += 2 * u), 0 != f2 && (x = e2.GPOS.readValueRecord(r3, p2, f2), p2 += 2 * l2), g.push({ gid2: m, val1: P, val2: x });
            }
            i4.pairsets.push(g);
          }
        }
        if (2 == i4.fmt) {
          var b5 = o2.readUshort(r3, a7);
          a7 += 2;
          var y = o2.readUshort(r3, a7);
          a7 += 2;
          var F = o2.readUshort(r3, a7);
          a7 += 2;
          var C = o2.readUshort(r3, a7);
          a7 += 2, i4.classDef1 = e2._lctf.readClassDef(r3, s2 + b5), i4.classDef2 = e2._lctf.readClassDef(r3, s2 + y), i4.matrix = [];
          for (c6 = 0; c6 < F; c6++) {
            var _ = [];
            for (S = 0; S < C; S++) {
              var P = null, x = null;
              0 != d2 && (P = e2.GPOS.readValueRecord(r3, a7, d2), a7 += 2 * u), 0 != f2 && (x = e2.GPOS.readValueRecord(r3, a7, f2), a7 += 2 * l2), _.push({ val1: P, val2: x });
            }
            i4.matrix.push(_);
          }
        }
      } else if (4 == t4 && 1 == i4.fmt) i4.markCoverage = e2._lctf.readCoverage(r3, o2.readUshort(r3, a7) + s2), i4.baseCoverage = e2._lctf.readCoverage(r3, o2.readUshort(r3, a7 + 2) + s2), i4.markClassCount = o2.readUshort(r3, a7 + 4), i4.markArray = e2.GPOS.readMarkArray(r3, o2.readUshort(r3, a7 + 6) + s2), i4.baseArray = e2.GPOS.readBaseArray(r3, o2.readUshort(r3, a7 + 8) + s2, i4.markClassCount);
      else if (6 == t4 && 1 == i4.fmt) i4.mark1Coverage = e2._lctf.readCoverage(r3, o2.readUshort(r3, a7) + s2), i4.mark2Coverage = e2._lctf.readCoverage(r3, o2.readUshort(r3, a7 + 2) + s2), i4.markClassCount = o2.readUshort(r3, a7 + 4), i4.mark1Array = e2.GPOS.readMarkArray(r3, o2.readUshort(r3, a7 + 6) + s2), i4.mark2Array = e2.GPOS.readBaseArray(r3, o2.readUshort(r3, a7 + 8) + s2, i4.markClassCount);
      else {
        if (9 == t4 && 1 == i4.fmt) {
          var I = o2.readUshort(r3, a7);
          a7 += 2;
          var w = o2.readUint(r3, a7);
          if (a7 += 4, 9 == n2.ltype) n2.ltype = I;
          else if (n2.ltype != I) throw "invalid extension substitution";
          return e2.GPOS.subt(r3, n2.ltype, s2 + w);
        }
        console.debug("unsupported GPOS table LookupType", t4, "format", i4.fmt);
      }
      return i4;
    }, e2.GPOS.readValueRecord = function(r3, t4, a7) {
      var n2 = e2._bin, o2 = [];
      return o2.push(1 & a7 ? n2.readShort(r3, t4) : 0), t4 += 1 & a7 ? 2 : 0, o2.push(2 & a7 ? n2.readShort(r3, t4) : 0), t4 += 2 & a7 ? 2 : 0, o2.push(4 & a7 ? n2.readShort(r3, t4) : 0), t4 += 4 & a7 ? 2 : 0, o2.push(8 & a7 ? n2.readShort(r3, t4) : 0), t4 += 8 & a7 ? 2 : 0, o2;
    }, e2.GPOS.readBaseArray = function(r3, t4, a7) {
      var n2 = e2._bin, o2 = [], s2 = t4, i4 = n2.readUshort(r3, t4);
      t4 += 2;
      for (var h = 0; h < i4; h++) {
        for (var d2 = [], f2 = 0; f2 < a7; f2++) d2.push(e2.GPOS.readAnchorRecord(r3, s2 + n2.readUshort(r3, t4))), t4 += 2;
        o2.push(d2);
      }
      return o2;
    }, e2.GPOS.readMarkArray = function(r3, t4) {
      var a7 = e2._bin, n2 = [], o2 = t4, s2 = a7.readUshort(r3, t4);
      t4 += 2;
      for (var i4 = 0; i4 < s2; i4++) {
        var h = e2.GPOS.readAnchorRecord(r3, a7.readUshort(r3, t4 + 2) + o2);
        h.markClass = a7.readUshort(r3, t4), n2.push(h), t4 += 4;
      }
      return n2;
    }, e2.GPOS.readAnchorRecord = function(r3, t4) {
      var a7 = e2._bin, n2 = {};
      return n2.fmt = a7.readUshort(r3, t4), n2.x = a7.readShort(r3, t4 + 2), n2.y = a7.readShort(r3, t4 + 4), n2;
    }, e2.GSUB = {}, e2.GSUB.parse = function(r3, t4, a7, n2) {
      return e2._lctf.parse(r3, t4, a7, n2, e2.GSUB.subt);
    }, e2.GSUB.subt = function(r3, t4, a7, n2) {
      var o2 = e2._bin, s2 = a7, i4 = {};
      if (i4.fmt = o2.readUshort(r3, a7), a7 += 2, 1 != t4 && 2 != t4 && 4 != t4 && 5 != t4 && 6 != t4) return null;
      if (1 == t4 || 2 == t4 || 4 == t4 || 5 == t4 && i4.fmt <= 2 || 6 == t4 && i4.fmt <= 2) {
        var h = o2.readUshort(r3, a7);
        a7 += 2, i4.coverage = e2._lctf.readCoverage(r3, s2 + h);
      }
      if (1 == t4 && i4.fmt >= 1 && i4.fmt <= 2) {
        if (1 == i4.fmt) i4.delta = o2.readShort(r3, a7), a7 += 2;
        else if (2 == i4.fmt) {
          var d2 = o2.readUshort(r3, a7);
          a7 += 2, i4.newg = o2.readUshorts(r3, a7, d2), a7 += 2 * i4.newg.length;
        }
      } else if (2 == t4 && 1 == i4.fmt) {
        d2 = o2.readUshort(r3, a7);
        a7 += 2, i4.seqs = [];
        for (var f2 = 0; f2 < d2; f2++) {
          var u = o2.readUshort(r3, a7) + s2;
          a7 += 2;
          var l2 = o2.readUshort(r3, u);
          i4.seqs.push(o2.readUshorts(r3, u + 2, l2));
        }
      } else if (4 == t4) {
        i4.vals = [];
        d2 = o2.readUshort(r3, a7);
        a7 += 2;
        for (f2 = 0; f2 < d2; f2++) {
          var v5 = o2.readUshort(r3, a7);
          a7 += 2, i4.vals.push(e2.GSUB.readLigatureSet(r3, s2 + v5));
        }
      } else if (5 == t4 && 2 == i4.fmt) {
        if (2 == i4.fmt) {
          var c6 = o2.readUshort(r3, a7);
          a7 += 2, i4.cDef = e2._lctf.readClassDef(r3, s2 + c6), i4.scset = [];
          var p2 = o2.readUshort(r3, a7);
          a7 += 2;
          for (f2 = 0; f2 < p2; f2++) {
            var U = o2.readUshort(r3, a7);
            a7 += 2, i4.scset.push(0 == U ? null : e2.GSUB.readSubClassSet(r3, s2 + U));
          }
        }
      } else if (6 == t4 && 3 == i4.fmt) {
        if (3 == i4.fmt) {
          for (f2 = 0; f2 < 3; f2++) {
            d2 = o2.readUshort(r3, a7);
            a7 += 2;
            for (var g = [], S = 0; S < d2; S++) g.push(e2._lctf.readCoverage(r3, s2 + o2.readUshort(r3, a7 + 2 * S)));
            a7 += 2 * d2, 0 == f2 && (i4.backCvg = g), 1 == f2 && (i4.inptCvg = g), 2 == f2 && (i4.ahedCvg = g);
          }
          d2 = o2.readUshort(r3, a7);
          a7 += 2, i4.lookupRec = e2.GSUB.readSubstLookupRecords(r3, a7, d2);
        }
      } else {
        if (7 == t4 && 1 == i4.fmt) {
          var m = o2.readUshort(r3, a7);
          a7 += 2;
          var b5 = o2.readUint(r3, a7);
          if (a7 += 4, 9 == n2.ltype) n2.ltype = m;
          else if (n2.ltype != m) throw "invalid extension substitution";
          return e2.GSUB.subt(r3, n2.ltype, s2 + b5);
        }
        console.debug("unsupported GSUB table LookupType", t4, "format", i4.fmt);
      }
      return i4;
    }, e2.GSUB.readSubClassSet = function(r3, t4) {
      var a7 = e2._bin.readUshort, n2 = t4, o2 = [], s2 = a7(r3, t4);
      t4 += 2;
      for (var i4 = 0; i4 < s2; i4++) {
        var h = a7(r3, t4);
        t4 += 2, o2.push(e2.GSUB.readSubClassRule(r3, n2 + h));
      }
      return o2;
    }, e2.GSUB.readSubClassRule = function(r3, t4) {
      var a7 = e2._bin.readUshort, n2 = {}, o2 = a7(r3, t4), s2 = a7(r3, t4 += 2);
      t4 += 2, n2.input = [];
      for (var i4 = 0; i4 < o2 - 1; i4++) n2.input.push(a7(r3, t4)), t4 += 2;
      return n2.substLookupRecords = e2.GSUB.readSubstLookupRecords(r3, t4, s2), n2;
    }, e2.GSUB.readSubstLookupRecords = function(r3, t4, a7) {
      for (var n2 = e2._bin.readUshort, o2 = [], s2 = 0; s2 < a7; s2++) o2.push(n2(r3, t4), n2(r3, t4 + 2)), t4 += 4;
      return o2;
    }, e2.GSUB.readChainSubClassSet = function(r3, t4) {
      var a7 = e2._bin, n2 = t4, o2 = [], s2 = a7.readUshort(r3, t4);
      t4 += 2;
      for (var i4 = 0; i4 < s2; i4++) {
        var h = a7.readUshort(r3, t4);
        t4 += 2, o2.push(e2.GSUB.readChainSubClassRule(r3, n2 + h));
      }
      return o2;
    }, e2.GSUB.readChainSubClassRule = function(r3, t4) {
      for (var a7 = e2._bin, n2 = {}, o2 = ["backtrack", "input", "lookahead"], s2 = 0; s2 < o2.length; s2++) {
        var i4 = a7.readUshort(r3, t4);
        t4 += 2, 1 == s2 && i4--, n2[o2[s2]] = a7.readUshorts(r3, t4, i4), t4 += 2 * n2[o2[s2]].length;
      }
      i4 = a7.readUshort(r3, t4);
      return t4 += 2, n2.subst = a7.readUshorts(r3, t4, 2 * i4), t4 += 2 * n2.subst.length, n2;
    }, e2.GSUB.readLigatureSet = function(r3, t4) {
      var a7 = e2._bin, n2 = t4, o2 = [], s2 = a7.readUshort(r3, t4);
      t4 += 2;
      for (var i4 = 0; i4 < s2; i4++) {
        var h = a7.readUshort(r3, t4);
        t4 += 2, o2.push(e2.GSUB.readLigature(r3, n2 + h));
      }
      return o2;
    }, e2.GSUB.readLigature = function(r3, t4) {
      var a7 = e2._bin, n2 = { chain: [] };
      n2.nglyph = a7.readUshort(r3, t4), t4 += 2;
      var o2 = a7.readUshort(r3, t4);
      t4 += 2;
      for (var s2 = 0; s2 < o2 - 1; s2++) n2.chain.push(a7.readUshort(r3, t4)), t4 += 2;
      return n2;
    }, e2.head = {}, e2.head.parse = function(r3, t4, a7) {
      var n2 = e2._bin, o2 = {};
      return n2.readFixed(r3, t4), t4 += 4, o2.fontRevision = n2.readFixed(r3, t4), t4 += 4, n2.readUint(r3, t4), t4 += 4, n2.readUint(r3, t4), t4 += 4, o2.flags = n2.readUshort(r3, t4), t4 += 2, o2.unitsPerEm = n2.readUshort(r3, t4), t4 += 2, o2.created = n2.readUint64(r3, t4), t4 += 8, o2.modified = n2.readUint64(r3, t4), t4 += 8, o2.xMin = n2.readShort(r3, t4), t4 += 2, o2.yMin = n2.readShort(r3, t4), t4 += 2, o2.xMax = n2.readShort(r3, t4), t4 += 2, o2.yMax = n2.readShort(r3, t4), t4 += 2, o2.macStyle = n2.readUshort(r3, t4), t4 += 2, o2.lowestRecPPEM = n2.readUshort(r3, t4), t4 += 2, o2.fontDirectionHint = n2.readShort(r3, t4), t4 += 2, o2.indexToLocFormat = n2.readShort(r3, t4), t4 += 2, o2.glyphDataFormat = n2.readShort(r3, t4), t4 += 2, o2;
    }, e2.hhea = {}, e2.hhea.parse = function(r3, t4, a7) {
      var n2 = e2._bin, o2 = {};
      return n2.readFixed(r3, t4), t4 += 4, o2.ascender = n2.readShort(r3, t4), t4 += 2, o2.descender = n2.readShort(r3, t4), t4 += 2, o2.lineGap = n2.readShort(r3, t4), t4 += 2, o2.advanceWidthMax = n2.readUshort(r3, t4), t4 += 2, o2.minLeftSideBearing = n2.readShort(r3, t4), t4 += 2, o2.minRightSideBearing = n2.readShort(r3, t4), t4 += 2, o2.xMaxExtent = n2.readShort(r3, t4), t4 += 2, o2.caretSlopeRise = n2.readShort(r3, t4), t4 += 2, o2.caretSlopeRun = n2.readShort(r3, t4), t4 += 2, o2.caretOffset = n2.readShort(r3, t4), t4 += 2, t4 += 8, o2.metricDataFormat = n2.readShort(r3, t4), t4 += 2, o2.numberOfHMetrics = n2.readUshort(r3, t4), t4 += 2, o2;
    }, e2.hmtx = {}, e2.hmtx.parse = function(r3, t4, a7, n2) {
      for (var o2 = e2._bin, s2 = { aWidth: [], lsBearing: [] }, i4 = 0, h = 0, d2 = 0; d2 < n2.maxp.numGlyphs; d2++) d2 < n2.hhea.numberOfHMetrics && (i4 = o2.readUshort(r3, t4), t4 += 2, h = o2.readShort(r3, t4), t4 += 2), s2.aWidth.push(i4), s2.lsBearing.push(h);
      return s2;
    }, e2.kern = {}, e2.kern.parse = function(r3, t4, a7, n2) {
      var o2 = e2._bin, s2 = o2.readUshort(r3, t4);
      if (t4 += 2, 1 == s2) return e2.kern.parseV1(r3, t4 - 2, a7, n2);
      var i4 = o2.readUshort(r3, t4);
      t4 += 2;
      for (var h = { glyph1: [], rval: [] }, d2 = 0; d2 < i4; d2++) {
        t4 += 2;
        a7 = o2.readUshort(r3, t4);
        t4 += 2;
        var f2 = o2.readUshort(r3, t4);
        t4 += 2;
        var u = f2 >>> 8;
        if (0 != (u &= 15)) throw "unknown kern table format: " + u;
        t4 = e2.kern.readFormat0(r3, t4, h);
      }
      return h;
    }, e2.kern.parseV1 = function(r3, t4, a7, n2) {
      var o2 = e2._bin;
      o2.readFixed(r3, t4), t4 += 4;
      var s2 = o2.readUint(r3, t4);
      t4 += 4;
      for (var i4 = { glyph1: [], rval: [] }, h = 0; h < s2; h++) {
        o2.readUint(r3, t4), t4 += 4;
        var d2 = o2.readUshort(r3, t4);
        t4 += 2, o2.readUshort(r3, t4), t4 += 2;
        var f2 = d2 >>> 8;
        if (0 != (f2 &= 15)) throw "unknown kern table format: " + f2;
        t4 = e2.kern.readFormat0(r3, t4, i4);
      }
      return i4;
    }, e2.kern.readFormat0 = function(r3, t4, a7) {
      var n2 = e2._bin, o2 = -1, s2 = n2.readUshort(r3, t4);
      t4 += 2, n2.readUshort(r3, t4), t4 += 2, n2.readUshort(r3, t4), t4 += 2, n2.readUshort(r3, t4), t4 += 2;
      for (var i4 = 0; i4 < s2; i4++) {
        var h = n2.readUshort(r3, t4);
        t4 += 2;
        var d2 = n2.readUshort(r3, t4);
        t4 += 2;
        var f2 = n2.readShort(r3, t4);
        t4 += 2, h != o2 && (a7.glyph1.push(h), a7.rval.push({ glyph2: [], vals: [] }));
        var u = a7.rval[a7.rval.length - 1];
        u.glyph2.push(d2), u.vals.push(f2), o2 = h;
      }
      return t4;
    }, e2.loca = {}, e2.loca.parse = function(r3, t4, a7, n2) {
      var o2 = e2._bin, s2 = [], i4 = n2.head.indexToLocFormat, h = n2.maxp.numGlyphs + 1;
      if (0 == i4) for (var d2 = 0; d2 < h; d2++) s2.push(o2.readUshort(r3, t4 + (d2 << 1)) << 1);
      if (1 == i4) for (d2 = 0; d2 < h; d2++) s2.push(o2.readUint(r3, t4 + (d2 << 2)));
      return s2;
    }, e2.maxp = {}, e2.maxp.parse = function(r3, t4, a7) {
      var n2 = e2._bin, o2 = {}, s2 = n2.readUint(r3, t4);
      return t4 += 4, o2.numGlyphs = n2.readUshort(r3, t4), t4 += 2, 65536 == s2 && (o2.maxPoints = n2.readUshort(r3, t4), t4 += 2, o2.maxContours = n2.readUshort(r3, t4), t4 += 2, o2.maxCompositePoints = n2.readUshort(r3, t4), t4 += 2, o2.maxCompositeContours = n2.readUshort(r3, t4), t4 += 2, o2.maxZones = n2.readUshort(r3, t4), t4 += 2, o2.maxTwilightPoints = n2.readUshort(r3, t4), t4 += 2, o2.maxStorage = n2.readUshort(r3, t4), t4 += 2, o2.maxFunctionDefs = n2.readUshort(r3, t4), t4 += 2, o2.maxInstructionDefs = n2.readUshort(r3, t4), t4 += 2, o2.maxStackElements = n2.readUshort(r3, t4), t4 += 2, o2.maxSizeOfInstructions = n2.readUshort(r3, t4), t4 += 2, o2.maxComponentElements = n2.readUshort(r3, t4), t4 += 2, o2.maxComponentDepth = n2.readUshort(r3, t4), t4 += 2), o2;
    }, e2.name = {}, e2.name.parse = function(r3, t4, a7) {
      var n2 = e2._bin, o2 = {};
      n2.readUshort(r3, t4), t4 += 2;
      var s2 = n2.readUshort(r3, t4);
      t4 += 2, n2.readUshort(r3, t4);
      for (var i4, h = ["copyright", "fontFamily", "fontSubfamily", "ID", "fullName", "version", "postScriptName", "trademark", "manufacturer", "designer", "description", "urlVendor", "urlDesigner", "licence", "licenceURL", "---", "typoFamilyName", "typoSubfamilyName", "compatibleFull", "sampleText", "postScriptCID", "wwsFamilyName", "wwsSubfamilyName", "lightPalette", "darkPalette"], d2 = t4 += 2, f2 = 0; f2 < s2; f2++) {
        var u = n2.readUshort(r3, t4);
        t4 += 2;
        var l2 = n2.readUshort(r3, t4);
        t4 += 2;
        var v5 = n2.readUshort(r3, t4);
        t4 += 2;
        var c6 = n2.readUshort(r3, t4);
        t4 += 2;
        var p2 = n2.readUshort(r3, t4);
        t4 += 2;
        var U = n2.readUshort(r3, t4);
        t4 += 2;
        var g, S = h[c6], m = d2 + 12 * s2 + U;
        if (0 == u) g = n2.readUnicode(r3, m, p2 / 2);
        else if (3 == u && 0 == l2) g = n2.readUnicode(r3, m, p2 / 2);
        else if (0 == l2) g = n2.readASCII(r3, m, p2);
        else if (1 == l2) g = n2.readUnicode(r3, m, p2 / 2);
        else if (3 == l2) g = n2.readUnicode(r3, m, p2 / 2);
        else {
          if (1 != u) throw "unknown encoding " + l2 + ", platformID: " + u;
          g = n2.readASCII(r3, m, p2), console.debug("reading unknown MAC encoding " + l2 + " as ASCII");
        }
        var b5 = "p" + u + "," + v5.toString(16);
        null == o2[b5] && (o2[b5] = {}), o2[b5][void 0 !== S ? S : c6] = g, o2[b5]._lang = v5;
      }
      for (var y in o2) if (null != o2[y].postScriptName && 1033 == o2[y]._lang) return o2[y];
      for (var y in o2) if (null != o2[y].postScriptName && 0 == o2[y]._lang) return o2[y];
      for (var y in o2) if (null != o2[y].postScriptName && 3084 == o2[y]._lang) return o2[y];
      for (var y in o2) if (null != o2[y].postScriptName) return o2[y];
      for (var y in o2) {
        i4 = y;
        break;
      }
      return console.debug("returning name table with languageID " + o2[i4]._lang), o2[i4];
    }, e2["OS/2"] = {}, e2["OS/2"].parse = function(r3, t4, a7) {
      var n2 = e2._bin.readUshort(r3, t4);
      t4 += 2;
      var o2 = {};
      if (0 == n2) e2["OS/2"].version0(r3, t4, o2);
      else if (1 == n2) e2["OS/2"].version1(r3, t4, o2);
      else if (2 == n2 || 3 == n2 || 4 == n2) e2["OS/2"].version2(r3, t4, o2);
      else {
        if (5 != n2) throw "unknown OS/2 table version: " + n2;
        e2["OS/2"].version5(r3, t4, o2);
      }
      return o2;
    }, e2["OS/2"].version0 = function(r3, t4, a7) {
      var n2 = e2._bin;
      return a7.xAvgCharWidth = n2.readShort(r3, t4), t4 += 2, a7.usWeightClass = n2.readUshort(r3, t4), t4 += 2, a7.usWidthClass = n2.readUshort(r3, t4), t4 += 2, a7.fsType = n2.readUshort(r3, t4), t4 += 2, a7.ySubscriptXSize = n2.readShort(r3, t4), t4 += 2, a7.ySubscriptYSize = n2.readShort(r3, t4), t4 += 2, a7.ySubscriptXOffset = n2.readShort(r3, t4), t4 += 2, a7.ySubscriptYOffset = n2.readShort(r3, t4), t4 += 2, a7.ySuperscriptXSize = n2.readShort(r3, t4), t4 += 2, a7.ySuperscriptYSize = n2.readShort(r3, t4), t4 += 2, a7.ySuperscriptXOffset = n2.readShort(r3, t4), t4 += 2, a7.ySuperscriptYOffset = n2.readShort(r3, t4), t4 += 2, a7.yStrikeoutSize = n2.readShort(r3, t4), t4 += 2, a7.yStrikeoutPosition = n2.readShort(r3, t4), t4 += 2, a7.sFamilyClass = n2.readShort(r3, t4), t4 += 2, a7.panose = n2.readBytes(r3, t4, 10), t4 += 10, a7.ulUnicodeRange1 = n2.readUint(r3, t4), t4 += 4, a7.ulUnicodeRange2 = n2.readUint(r3, t4), t4 += 4, a7.ulUnicodeRange3 = n2.readUint(r3, t4), t4 += 4, a7.ulUnicodeRange4 = n2.readUint(r3, t4), t4 += 4, a7.achVendID = [n2.readInt8(r3, t4), n2.readInt8(r3, t4 + 1), n2.readInt8(r3, t4 + 2), n2.readInt8(r3, t4 + 3)], t4 += 4, a7.fsSelection = n2.readUshort(r3, t4), t4 += 2, a7.usFirstCharIndex = n2.readUshort(r3, t4), t4 += 2, a7.usLastCharIndex = n2.readUshort(r3, t4), t4 += 2, a7.sTypoAscender = n2.readShort(r3, t4), t4 += 2, a7.sTypoDescender = n2.readShort(r3, t4), t4 += 2, a7.sTypoLineGap = n2.readShort(r3, t4), t4 += 2, a7.usWinAscent = n2.readUshort(r3, t4), t4 += 2, a7.usWinDescent = n2.readUshort(r3, t4), t4 += 2;
    }, e2["OS/2"].version1 = function(r3, t4, a7) {
      var n2 = e2._bin;
      return t4 = e2["OS/2"].version0(r3, t4, a7), a7.ulCodePageRange1 = n2.readUint(r3, t4), t4 += 4, a7.ulCodePageRange2 = n2.readUint(r3, t4), t4 += 4;
    }, e2["OS/2"].version2 = function(r3, t4, a7) {
      var n2 = e2._bin;
      return t4 = e2["OS/2"].version1(r3, t4, a7), a7.sxHeight = n2.readShort(r3, t4), t4 += 2, a7.sCapHeight = n2.readShort(r3, t4), t4 += 2, a7.usDefault = n2.readUshort(r3, t4), t4 += 2, a7.usBreak = n2.readUshort(r3, t4), t4 += 2, a7.usMaxContext = n2.readUshort(r3, t4), t4 += 2;
    }, e2["OS/2"].version5 = function(r3, t4, a7) {
      var n2 = e2._bin;
      return t4 = e2["OS/2"].version2(r3, t4, a7), a7.usLowerOpticalPointSize = n2.readUshort(r3, t4), t4 += 2, a7.usUpperOpticalPointSize = n2.readUshort(r3, t4), t4 += 2;
    }, e2.post = {}, e2.post.parse = function(r3, t4, a7) {
      var n2 = e2._bin, o2 = {};
      return o2.version = n2.readFixed(r3, t4), t4 += 4, o2.italicAngle = n2.readFixed(r3, t4), t4 += 4, o2.underlinePosition = n2.readShort(r3, t4), t4 += 2, o2.underlineThickness = n2.readShort(r3, t4), t4 += 2, o2;
    }, null == e2 && (e2 = {}), null == e2.U && (e2.U = {}), e2.U.codeToGlyph = function(r3, e3) {
      var t4 = r3.cmap, a7 = -1;
      if (null != t4.p0e4 ? a7 = t4.p0e4 : null != t4.p3e1 ? a7 = t4.p3e1 : null != t4.p1e0 ? a7 = t4.p1e0 : null != t4.p0e3 && (a7 = t4.p0e3), -1 == a7) throw "no familiar platform and encoding!";
      var n2 = t4.tables[a7];
      if (0 == n2.format) return e3 >= n2.map.length ? 0 : n2.map[e3];
      if (4 == n2.format) {
        for (var o2 = -1, s2 = 0; s2 < n2.endCount.length; s2++) if (e3 <= n2.endCount[s2]) {
          o2 = s2;
          break;
        }
        if (-1 == o2) return 0;
        if (n2.startCount[o2] > e3) return 0;
        return 65535 & (0 != n2.idRangeOffset[o2] ? n2.glyphIdArray[e3 - n2.startCount[o2] + (n2.idRangeOffset[o2] >> 1) - (n2.idRangeOffset.length - o2)] : e3 + n2.idDelta[o2]);
      }
      if (12 == n2.format) {
        if (e3 > n2.groups[n2.groups.length - 1][1]) return 0;
        for (s2 = 0; s2 < n2.groups.length; s2++) {
          var i4 = n2.groups[s2];
          if (i4[0] <= e3 && e3 <= i4[1]) return i4[2] + (e3 - i4[0]);
        }
        return 0;
      }
      throw "unknown cmap table format " + n2.format;
    }, e2.U.glyphToPath = function(r3, t4) {
      var a7 = { cmds: [], crds: [] };
      if (r3.SVG && r3.SVG.entries[t4]) {
        var n2 = r3.SVG.entries[t4];
        return null == n2 ? a7 : ("string" == typeof n2 && (n2 = e2.SVG.toPath(n2), r3.SVG.entries[t4] = n2), n2);
      }
      if (r3.CFF) {
        var o2 = { x: 0, y: 0, stack: [], nStems: 0, haveWidth: false, width: r3.CFF.Private ? r3.CFF.Private.defaultWidthX : 0, open: false }, s2 = r3.CFF, i4 = r3.CFF.Private;
        if (s2.ROS) {
          for (var h = 0; s2.FDSelect[h + 2] <= t4; ) h += 2;
          i4 = s2.FDArray[s2.FDSelect[h + 1]].Private;
        }
        e2.U._drawCFF(r3.CFF.CharStrings[t4], o2, s2, i4, a7);
      } else r3.glyf && e2.U._drawGlyf(t4, r3, a7);
      return a7;
    }, e2.U._drawGlyf = function(r3, t4, a7) {
      var n2 = t4.glyf[r3];
      null == n2 && (n2 = t4.glyf[r3] = e2.glyf._parseGlyf(t4, r3)), null != n2 && (n2.noc > -1 ? e2.U._simpleGlyph(n2, a7) : e2.U._compoGlyph(n2, t4, a7));
    }, e2.U._simpleGlyph = function(r3, t4) {
      for (var a7 = 0; a7 < r3.noc; a7++) {
        for (var n2 = 0 == a7 ? 0 : r3.endPts[a7 - 1] + 1, o2 = r3.endPts[a7], s2 = n2; s2 <= o2; s2++) {
          var i4 = s2 == n2 ? o2 : s2 - 1, h = s2 == o2 ? n2 : s2 + 1, d2 = 1 & r3.flags[s2], f2 = 1 & r3.flags[i4], u = 1 & r3.flags[h], l2 = r3.xs[s2], v5 = r3.ys[s2];
          if (s2 == n2) if (d2) {
            if (!f2) {
              e2.U.P.moveTo(t4, l2, v5);
              continue;
            }
            e2.U.P.moveTo(t4, r3.xs[i4], r3.ys[i4]);
          } else f2 ? e2.U.P.moveTo(t4, r3.xs[i4], r3.ys[i4]) : e2.U.P.moveTo(t4, (r3.xs[i4] + l2) / 2, (r3.ys[i4] + v5) / 2);
          d2 ? f2 && e2.U.P.lineTo(t4, l2, v5) : u ? e2.U.P.qcurveTo(t4, l2, v5, r3.xs[h], r3.ys[h]) : e2.U.P.qcurveTo(t4, l2, v5, (l2 + r3.xs[h]) / 2, (v5 + r3.ys[h]) / 2);
        }
        e2.U.P.closePath(t4);
      }
    }, e2.U._compoGlyph = function(r3, t4, a7) {
      for (var n2 = 0; n2 < r3.parts.length; n2++) {
        var o2 = { cmds: [], crds: [] }, s2 = r3.parts[n2];
        e2.U._drawGlyf(s2.glyphIndex, t4, o2);
        for (var i4 = s2.m, h = 0; h < o2.crds.length; h += 2) {
          var d2 = o2.crds[h], f2 = o2.crds[h + 1];
          a7.crds.push(d2 * i4.a + f2 * i4.b + i4.tx), a7.crds.push(d2 * i4.c + f2 * i4.d + i4.ty);
        }
        for (h = 0; h < o2.cmds.length; h++) a7.cmds.push(o2.cmds[h]);
      }
    }, e2.U._getGlyphClass = function(r3, t4) {
      var a7 = e2._lctf.getInterval(t4, r3);
      return -1 == a7 ? 0 : t4[a7 + 2];
    }, e2.U._applySubs = function(r3, t4, a7, n2) {
      for (var o2 = r3.length - t4 - 1, s2 = 0; s2 < a7.tabs.length; s2++) if (null != a7.tabs[s2]) {
        var i4, h = a7.tabs[s2];
        if (!h.coverage || -1 != (i4 = e2._lctf.coverageIndex(h.coverage, r3[t4]))) {
          if (1 == a7.ltype) r3[t4], 1 == h.fmt ? r3[t4] = r3[t4] + h.delta : r3[t4] = h.newg[i4];
          else if (4 == a7.ltype) for (var d2 = h.vals[i4], f2 = 0; f2 < d2.length; f2++) {
            var u = d2[f2], l2 = u.chain.length;
            if (!(l2 > o2)) {
              for (var v5 = true, c6 = 0, p2 = 0; p2 < l2; p2++) {
                for (; -1 == r3[t4 + c6 + (1 + p2)]; ) c6++;
                u.chain[p2] != r3[t4 + c6 + (1 + p2)] && (v5 = false);
              }
              if (v5) {
                r3[t4] = u.nglyph;
                for (p2 = 0; p2 < l2 + c6; p2++) r3[t4 + p2 + 1] = -1;
                break;
              }
            }
          }
          else if (5 == a7.ltype && 2 == h.fmt) for (var U = e2._lctf.getInterval(h.cDef, r3[t4]), g = h.cDef[U + 2], S = h.scset[g], m = 0; m < S.length; m++) {
            var b5 = S[m], y = b5.input;
            if (!(y.length > o2)) {
              for (v5 = true, p2 = 0; p2 < y.length; p2++) {
                var F = e2._lctf.getInterval(h.cDef, r3[t4 + 1 + p2]);
                if (-1 == U && h.cDef[F + 2] != y[p2]) {
                  v5 = false;
                  break;
                }
              }
              if (v5) {
                var C = b5.substLookupRecords;
                for (f2 = 0; f2 < C.length; f2 += 2) C[f2], C[f2 + 1];
              }
            }
          }
          else if (6 == a7.ltype && 3 == h.fmt) {
            if (!e2.U._glsCovered(r3, h.backCvg, t4 - h.backCvg.length)) continue;
            if (!e2.U._glsCovered(r3, h.inptCvg, t4)) continue;
            if (!e2.U._glsCovered(r3, h.ahedCvg, t4 + h.inptCvg.length)) continue;
            var _ = h.lookupRec;
            for (m = 0; m < _.length; m += 2) {
              U = _[m];
              var P = n2[_[m + 1]];
              e2.U._applySubs(r3, t4 + U, P, n2);
            }
          }
        }
      }
    }, e2.U._glsCovered = function(r3, t4, a7) {
      for (var n2 = 0; n2 < t4.length; n2++) {
        if (-1 == e2._lctf.coverageIndex(t4[n2], r3[a7 + n2])) return false;
      }
      return true;
    }, e2.U.glyphsToPath = function(r3, t4, a7) {
      for (var n2 = { cmds: [], crds: [] }, o2 = 0, s2 = 0; s2 < t4.length; s2++) {
        var i4 = t4[s2];
        if (-1 != i4) {
          for (var h = s2 < t4.length - 1 && -1 != t4[s2 + 1] ? t4[s2 + 1] : 0, d2 = e2.U.glyphToPath(r3, i4), f2 = 0; f2 < d2.crds.length; f2 += 2) n2.crds.push(d2.crds[f2] + o2), n2.crds.push(d2.crds[f2 + 1]);
          a7 && n2.cmds.push(a7);
          for (f2 = 0; f2 < d2.cmds.length; f2++) n2.cmds.push(d2.cmds[f2]);
          a7 && n2.cmds.push("X"), o2 += r3.hmtx.aWidth[i4], s2 < t4.length - 1 && (o2 += e2.U.getPairAdjustment(r3, i4, h));
        }
      }
      return n2;
    }, e2.U.P = {}, e2.U.P.moveTo = function(r3, e3, t4) {
      r3.cmds.push("M"), r3.crds.push(e3, t4);
    }, e2.U.P.lineTo = function(r3, e3, t4) {
      r3.cmds.push("L"), r3.crds.push(e3, t4);
    }, e2.U.P.curveTo = function(r3, e3, t4, a7, n2, o2, s2) {
      r3.cmds.push("C"), r3.crds.push(e3, t4, a7, n2, o2, s2);
    }, e2.U.P.qcurveTo = function(r3, e3, t4, a7, n2) {
      r3.cmds.push("Q"), r3.crds.push(e3, t4, a7, n2);
    }, e2.U.P.closePath = function(r3) {
      r3.cmds.push("Z");
    }, e2.U._drawCFF = function(r3, t4, a7, n2, o2) {
      for (var s2 = t4.stack, i4 = t4.nStems, h = t4.haveWidth, d2 = t4.width, f2 = t4.open, u = 0, l2 = t4.x, v5 = t4.y, c6 = 0, p2 = 0, U = 0, g = 0, S = 0, m = 0, b5 = 0, y = 0, F = 0, C = 0, _ = { val: 0, size: 0 }; u < r3.length; ) {
        e2.CFF.getCharString(r3, u, _);
        var P = _.val;
        if (u += _.size, "o1" == P || "o18" == P) s2.length % 2 != 0 && !h && (d2 = s2.shift() + n2.nominalWidthX), i4 += s2.length >> 1, s2.length = 0, h = true;
        else if ("o3" == P || "o23" == P) {
          s2.length % 2 != 0 && !h && (d2 = s2.shift() + n2.nominalWidthX), i4 += s2.length >> 1, s2.length = 0, h = true;
        } else if ("o4" == P) s2.length > 1 && !h && (d2 = s2.shift() + n2.nominalWidthX, h = true), f2 && e2.U.P.closePath(o2), v5 += s2.pop(), e2.U.P.moveTo(o2, l2, v5), f2 = true;
        else if ("o5" == P) for (; s2.length > 0; ) l2 += s2.shift(), v5 += s2.shift(), e2.U.P.lineTo(o2, l2, v5);
        else if ("o6" == P || "o7" == P) for (var x = s2.length, I = "o6" == P, w = 0; w < x; w++) {
          var k = s2.shift();
          I ? l2 += k : v5 += k, I = !I, e2.U.P.lineTo(o2, l2, v5);
        }
        else if ("o8" == P || "o24" == P) {
          x = s2.length;
          for (var G = 0; G + 6 <= x; ) c6 = l2 + s2.shift(), p2 = v5 + s2.shift(), U = c6 + s2.shift(), g = p2 + s2.shift(), l2 = U + s2.shift(), v5 = g + s2.shift(), e2.U.P.curveTo(o2, c6, p2, U, g, l2, v5), G += 6;
          "o24" == P && (l2 += s2.shift(), v5 += s2.shift(), e2.U.P.lineTo(o2, l2, v5));
        } else {
          if ("o11" == P) break;
          if ("o1234" == P || "o1235" == P || "o1236" == P || "o1237" == P) "o1234" == P && (p2 = v5, U = (c6 = l2 + s2.shift()) + s2.shift(), C = g = p2 + s2.shift(), m = g, y = v5, l2 = (b5 = (S = (F = U + s2.shift()) + s2.shift()) + s2.shift()) + s2.shift(), e2.U.P.curveTo(o2, c6, p2, U, g, F, C), e2.U.P.curveTo(o2, S, m, b5, y, l2, v5)), "o1235" == P && (c6 = l2 + s2.shift(), p2 = v5 + s2.shift(), U = c6 + s2.shift(), g = p2 + s2.shift(), F = U + s2.shift(), C = g + s2.shift(), S = F + s2.shift(), m = C + s2.shift(), b5 = S + s2.shift(), y = m + s2.shift(), l2 = b5 + s2.shift(), v5 = y + s2.shift(), s2.shift(), e2.U.P.curveTo(o2, c6, p2, U, g, F, C), e2.U.P.curveTo(o2, S, m, b5, y, l2, v5)), "o1236" == P && (c6 = l2 + s2.shift(), p2 = v5 + s2.shift(), U = c6 + s2.shift(), C = g = p2 + s2.shift(), m = g, b5 = (S = (F = U + s2.shift()) + s2.shift()) + s2.shift(), y = m + s2.shift(), l2 = b5 + s2.shift(), e2.U.P.curveTo(o2, c6, p2, U, g, F, C), e2.U.P.curveTo(o2, S, m, b5, y, l2, v5)), "o1237" == P && (c6 = l2 + s2.shift(), p2 = v5 + s2.shift(), U = c6 + s2.shift(), g = p2 + s2.shift(), F = U + s2.shift(), C = g + s2.shift(), S = F + s2.shift(), m = C + s2.shift(), b5 = S + s2.shift(), y = m + s2.shift(), Math.abs(b5 - l2) > Math.abs(y - v5) ? l2 = b5 + s2.shift() : v5 = y + s2.shift(), e2.U.P.curveTo(o2, c6, p2, U, g, F, C), e2.U.P.curveTo(o2, S, m, b5, y, l2, v5));
          else if ("o14" == P) {
            if (s2.length > 0 && !h && (d2 = s2.shift() + a7.nominalWidthX, h = true), 4 == s2.length) {
              var O = s2.shift(), T = s2.shift(), D = s2.shift(), B = s2.shift(), A = e2.CFF.glyphBySE(a7, D), R2 = e2.CFF.glyphBySE(a7, B);
              e2.U._drawCFF(a7.CharStrings[A], t4, a7, n2, o2), t4.x = O, t4.y = T, e2.U._drawCFF(a7.CharStrings[R2], t4, a7, n2, o2);
            }
            f2 && (e2.U.P.closePath(o2), f2 = false);
          } else if ("o19" == P || "o20" == P) {
            s2.length % 2 != 0 && !h && (d2 = s2.shift() + n2.nominalWidthX), i4 += s2.length >> 1, s2.length = 0, h = true, u += i4 + 7 >> 3;
          } else if ("o21" == P) s2.length > 2 && !h && (d2 = s2.shift() + n2.nominalWidthX, h = true), v5 += s2.pop(), l2 += s2.pop(), f2 && e2.U.P.closePath(o2), e2.U.P.moveTo(o2, l2, v5), f2 = true;
          else if ("o22" == P) s2.length > 1 && !h && (d2 = s2.shift() + n2.nominalWidthX, h = true), l2 += s2.pop(), f2 && e2.U.P.closePath(o2), e2.U.P.moveTo(o2, l2, v5), f2 = true;
          else if ("o25" == P) {
            for (; s2.length > 6; ) l2 += s2.shift(), v5 += s2.shift(), e2.U.P.lineTo(o2, l2, v5);
            c6 = l2 + s2.shift(), p2 = v5 + s2.shift(), U = c6 + s2.shift(), g = p2 + s2.shift(), l2 = U + s2.shift(), v5 = g + s2.shift(), e2.U.P.curveTo(o2, c6, p2, U, g, l2, v5);
          } else if ("o26" == P) for (s2.length % 2 && (l2 += s2.shift()); s2.length > 0; ) c6 = l2, p2 = v5 + s2.shift(), l2 = U = c6 + s2.shift(), v5 = (g = p2 + s2.shift()) + s2.shift(), e2.U.P.curveTo(o2, c6, p2, U, g, l2, v5);
          else if ("o27" == P) for (s2.length % 2 && (v5 += s2.shift()); s2.length > 0; ) p2 = v5, U = (c6 = l2 + s2.shift()) + s2.shift(), g = p2 + s2.shift(), l2 = U + s2.shift(), v5 = g, e2.U.P.curveTo(o2, c6, p2, U, g, l2, v5);
          else if ("o10" == P || "o29" == P) {
            var L = "o10" == P ? n2 : a7;
            if (0 == s2.length) console.debug("error: empty stack");
            else {
              var W = s2.pop(), M = L.Subrs[W + L.Bias];
              t4.x = l2, t4.y = v5, t4.nStems = i4, t4.haveWidth = h, t4.width = d2, t4.open = f2, e2.U._drawCFF(M, t4, a7, n2, o2), l2 = t4.x, v5 = t4.y, i4 = t4.nStems, h = t4.haveWidth, d2 = t4.width, f2 = t4.open;
            }
          } else if ("o30" == P || "o31" == P) {
            var V2 = s2.length, E = (G = 0, "o31" == P);
            for (G += V2 - (x = -3 & V2); G < x; ) E ? (p2 = v5, U = (c6 = l2 + s2.shift()) + s2.shift(), v5 = (g = p2 + s2.shift()) + s2.shift(), x - G == 5 ? (l2 = U + s2.shift(), G++) : l2 = U, E = false) : (c6 = l2, p2 = v5 + s2.shift(), U = c6 + s2.shift(), g = p2 + s2.shift(), l2 = U + s2.shift(), x - G == 5 ? (v5 = g + s2.shift(), G++) : v5 = g, E = true), e2.U.P.curveTo(o2, c6, p2, U, g, l2, v5), G += 4;
          } else {
            if ("o" == (P + "").charAt(0)) throw console.debug("Unknown operation: " + P, r3), P;
            s2.push(P);
          }
        }
      }
      t4.x = l2, t4.y = v5, t4.nStems = i4, t4.haveWidth = h, t4.width = d2, t4.open = f2;
    };
    var t3 = e2, a6 = { Typr: t3 };
    return r2.Typr = t3, r2.default = a6, Object.defineProperty(r2, "__esModule", { value: true }), r2;
  }({}).Typr;
}
)}
)
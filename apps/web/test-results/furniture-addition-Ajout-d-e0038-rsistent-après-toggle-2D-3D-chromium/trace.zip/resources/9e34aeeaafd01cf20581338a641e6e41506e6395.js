/** <<FontResolver> function dependency: unicodeFontResolverClientFactory>.init **/

troikaDefine(
function(){return (
function unicodeFontResolverClientFactory() {
  return function(t3) {
    var n2 = function() {
      this.buckets = /* @__PURE__ */ new Map();
    };
    n2.prototype.add = function(t4) {
      var n3 = t4 >> 5;
      this.buckets.set(n3, (this.buckets.get(n3) || 0) | 1 << (31 & t4));
    }, n2.prototype.has = function(t4) {
      var n3 = this.buckets.get(t4 >> 5);
      return void 0 !== n3 && 0 != (n3 & 1 << (31 & t4));
    }, n2.prototype.serialize = function() {
      var t4 = [];
      return this.buckets.forEach(function(n3, r3) {
        t4.push((+r3).toString(36) + ":" + n3.toString(36));
      }), t4.join(",");
    }, n2.prototype.deserialize = function(t4) {
      var n3 = this;
      this.buckets.clear(), t4.split(",").forEach(function(t5) {
        var r3 = t5.split(":");
        n3.buckets.set(parseInt(r3[0], 36), parseInt(r3[1], 36));
      });
    };
    var r2 = Math.pow(2, 8), e2 = r2 - 1, o2 = ~e2;
    function a6(t4) {
      var n3 = function(t5) {
        return t5 & o2;
      }(t4).toString(16), e3 = function(t5) {
        return (t5 & o2) + r2 - 1;
      }(t4).toString(16);
      return "codepoint-index/plane" + (t4 >> 16) + "/" + n3 + "-" + e3 + ".json";
    }
    function i4(t4, n3) {
      var r3 = t4 & e2, o3 = n3.codePointAt(r3 / 6 | 0);
      return 0 != ((o3 = (o3 || 48) - 48) & 1 << r3 % 6);
    }
    function u(t4, n3) {
      var r3;
      (r3 = t4, r3.replace(/U\+/gi, "").replace(/^,+|,+$/g, "").split(/,+/).map(function(t5) {
        return t5.split("-").map(function(t6) {
          return parseInt(t6.trim(), 16);
        });
      })).forEach(function(t5) {
        var r4 = t5[0], e3 = t5[1];
        void 0 === e3 && (e3 = r4), n3(r4, e3);
      });
    }
    function c6(t4, n3) {
      u(t4, function(t5, r3) {
        for (var e3 = t5; e3 <= r3; e3++) n3(e3);
      });
    }
    var s2 = {}, f2 = {}, l2 = /* @__PURE__ */ new WeakMap(), v5 = "https://cdn.jsdelivr.net/gh/lojjic/unicode-font-resolver@v1.0.1/packages/data";
    function d2(t4) {
      var r3 = l2.get(t4);
      return r3 || (r3 = new n2(), c6(t4.ranges, function(t5) {
        return r3.add(t5);
      }), l2.set(t4, r3)), r3;
    }
    var h, p2 = /* @__PURE__ */ new Map();
    function g(t4, n3, r3) {
      return t4[n3] ? n3 : t4[r3] ? r3 : function(t5) {
        for (var n4 in t5) return n4;
      }(t4);
    }
    function w(t4, n3) {
      var r3 = n3;
      if (!t4.includes(r3)) {
        r3 = 1 / 0;
        for (var e3 = 0; e3 < t4.length; e3++) Math.abs(t4[e3] - n3) < Math.abs(r3 - n3) && (r3 = t4[e3]);
      }
      return r3;
    }
    function k(t4) {
      return h || (h = /* @__PURE__ */ new Set(), c6("9-D,20,85,A0,1680,2000-200A,2028-202F,205F,3000", function(t5) {
        h.add(t5);
      })), h.has(t4);
    }
    return t3.CodePointSet = n2, t3.clearCache = function() {
      s2 = {}, f2 = {};
    }, t3.getFontsForString = function(t4, n3) {
      void 0 === n3 && (n3 = {});
      var r3, e3 = n3.lang;
      void 0 === e3 && (e3 = new RegExp("\\p{Script=Hangul}", "u").test(r3 = t4) ? "ko" : new RegExp("\\p{Script=Hiragana}|\\p{Script=Katakana}", "u").test(r3) ? "ja" : "en");
      var o3 = n3.category;
      void 0 === o3 && (o3 = "sans-serif");
      var u2 = n3.style;
      void 0 === u2 && (u2 = "normal");
      var c7 = n3.weight;
      void 0 === c7 && (c7 = 400);
      var l3 = (n3.dataUrl || v5).replace(/\/$/g, ""), h2 = /* @__PURE__ */ new Map(), y = new Uint8Array(t4.length), b5 = {}, m = {}, A = new Array(t4.length), S = /* @__PURE__ */ new Map(), j = false;
      function M(t5) {
        var n4 = p2.get(t5);
        return n4 || (n4 = fetch(l3 + "/" + t5).then(function(t6) {
          if (!t6.ok) throw new Error(t6.statusText);
          return t6.json().then(function(t7) {
            if (!Array.isArray(t7) || 1 !== t7[0]) throw new Error("Incorrect schema version; need 1, got " + t7[0]);
            return t7[1];
          });
        }).catch(function(n5) {
          if (l3 !== v5) return j || (console.error('unicode-font-resolver: Failed loading from dataUrl "' + l3 + '", trying default CDN. ' + n5.message), j = true), l3 = v5, p2.delete(t5), M(t5);
          throw n5;
        }), p2.set(t5, n4)), n4;
      }
      for (var P = function(n4) {
        var r4 = t4.codePointAt(n4), e4 = a6(r4);
        A[n4] = e4, s2[e4] || S.has(e4) || S.set(e4, M(e4).then(function(t5) {
          s2[e4] = t5;
        })), r4 > 65535 && (n4++, E = n4);
      }, E = 0; E < t4.length; E++) P(E);
      return Promise.all(S.values()).then(function() {
        S.clear();
        for (var n4 = function(n5) {
          var o4 = t4.codePointAt(n5), a7 = null, u3 = s2[A[n5]], c8 = void 0;
          for (var l4 in u3) {
            var v6 = m[l4];
            if (void 0 === v6 && (v6 = m[l4] = new RegExp(l4).test(e3 || "en")), v6) {
              for (var d3 in c8 = l4, u3[l4]) if (i4(o4, u3[l4][d3])) {
                a7 = d3;
                break;
              }
              break;
            }
          }
          if (!a7) {
            t: for (var h3 in u3) if (h3 !== c8) {
              for (var p3 in u3[h3]) if (i4(o4, u3[h3][p3])) {
                a7 = p3;
                break t;
              }
            }
          }
          a7 || (console.debug("No font coverage for U+" + o4.toString(16)), a7 = "latin"), A[n5] = a7, f2[a7] || S.has(a7) || S.set(a7, M("font-meta/" + a7 + ".json").then(function(t5) {
            f2[a7] = t5;
          })), o4 > 65535 && (n5++, r4 = n5);
        }, r4 = 0; r4 < t4.length; r4++) n4(r4);
        return Promise.all(S.values());
      }).then(function() {
        for (var n4, r4 = null, e4 = 0; e4 < t4.length; e4++) {
          var a7 = t4.codePointAt(e4);
          if (r4 && (k(a7) || d2(r4).has(a7))) y[e4] = y[e4 - 1];
          else {
            r4 = f2[A[e4]];
            var i5 = b5[r4.id];
            if (!i5) {
              var s3 = r4.typeforms, v6 = g(s3, o3, "sans-serif"), p3 = g(s3[v6], u2, "normal"), m2 = w(null === (n4 = s3[v6]) || void 0 === n4 ? void 0 : n4[p3], c7);
              i5 = b5[r4.id] = l3 + "/font-files/" + r4.id + "/" + v6 + "." + p3 + "." + m2 + ".woff";
            }
            var S2 = h2.get(i5);
            null == S2 && (S2 = h2.size, h2.set(i5, S2)), y[e4] = S2;
          }
          a7 > 65535 && (e4++, y[e4] = y[e4 - 1]);
        }
        return { fontUrls: Array.from(h2.keys()), chars: y };
      });
    }, Object.defineProperty(t3, "__esModule", { value: true }), t3;
  }({});
}
)}
)
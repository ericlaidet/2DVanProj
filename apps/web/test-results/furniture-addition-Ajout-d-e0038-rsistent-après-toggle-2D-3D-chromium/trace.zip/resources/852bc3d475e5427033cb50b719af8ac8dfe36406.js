/** <<FontResolver> function dependency: createFontResolver>.init **/

troikaDefine(
function(){return (
function createFontResolver(fontParser, unicodeFontResolverClient) {
  const parsedFonts = /* @__PURE__ */ Object.create(null);
  const loadingFonts = /* @__PURE__ */ Object.create(null);
  function doLoadFont(url, callback) {
    const onError = (err) => {
      console.error(`Failure loading font ${url}`, err);
    };
    try {
      const request = new XMLHttpRequest();
      request.open("get", url, true);
      request.responseType = "arraybuffer";
      request.onload = function() {
        if (request.status >= 400) {
          onError(new Error(request.statusText));
        } else if (request.status > 0) {
          try {
            const fontObj = fontParser(request.response);
            fontObj.src = url;
            callback(fontObj);
          } catch (e2) {
            onError(e2);
          }
        }
      };
      request.onerror = onError;
      request.send();
    } catch (err) {
      onError(err);
    }
  }
  function loadFont(fontUrl, callback) {
    let font = parsedFonts[fontUrl];
    if (font) {
      callback(font);
    } else if (loadingFonts[fontUrl]) {
      loadingFonts[fontUrl].push(callback);
    } else {
      loadingFonts[fontUrl] = [callback];
      doLoadFont(fontUrl, (fontObj) => {
        fontObj.src = fontUrl;
        parsedFonts[fontUrl] = fontObj;
        loadingFonts[fontUrl].forEach((cb2) => cb2(fontObj));
        delete loadingFonts[fontUrl];
      });
    }
  }
  return function(text, callback, {
    lang,
    fonts: userFonts = [],
    style = "normal",
    weight = "normal",
    unicodeFontsURL
  } = {}) {
    const charResolutions = new Uint8Array(text.length);
    const fontResolutions = [];
    if (!text.length) {
      allDone();
    }
    const fontIndices = /* @__PURE__ */ new Map();
    const fallbackRanges = [];
    if (style !== "italic") style = "normal";
    if (typeof weight !== "number") {
      weight = weight === "bold" ? 700 : 400;
    }
    if (userFonts && !Array.isArray(userFonts)) {
      userFonts = [userFonts];
    }
    userFonts = userFonts.slice().filter((def) => !def.lang || def.lang.test(lang)).reverse();
    if (userFonts.length) {
      const UNKNOWN = 0;
      const RESOLVED = 1;
      const NEEDS_FALLBACK = 2;
      let prevCharResult = UNKNOWN;
      (function resolveUserFonts(startIndex = 0) {
        for (let i4 = startIndex, iLen = text.length; i4 < iLen; i4++) {
          const codePoint = text.codePointAt(i4);
          if (prevCharResult === RESOLVED && fontResolutions[charResolutions[i4 - 1]].supportsCodePoint(codePoint) || i4 > 0 && /\s/.test(text[i4])) {
            charResolutions[i4] = charResolutions[i4 - 1];
            if (prevCharResult === NEEDS_FALLBACK) {
              fallbackRanges[fallbackRanges.length - 1][1] = i4;
            }
          } else {
            for (let j = charResolutions[i4], jLen = userFonts.length; j <= jLen; j++) {
              if (j === jLen) {
                const range = prevCharResult === NEEDS_FALLBACK ? fallbackRanges[fallbackRanges.length - 1] : fallbackRanges[fallbackRanges.length] = [i4, i4];
                range[1] = i4;
                prevCharResult = NEEDS_FALLBACK;
              } else {
                charResolutions[i4] = j;
                const { src, unicodeRange } = userFonts[j];
                if (!unicodeRange || isCodeInRanges(codePoint, unicodeRange)) {
                  const fontObj = parsedFonts[src];
                  if (!fontObj) {
                    loadFont(src, () => {
                      resolveUserFonts(i4);
                    });
                    return;
                  }
                  if (fontObj.supportsCodePoint(codePoint)) {
                    let fontIndex = fontIndices.get(fontObj);
                    if (typeof fontIndex !== "number") {
                      fontIndex = fontResolutions.length;
                      fontResolutions.push(fontObj);
                      fontIndices.set(fontObj, fontIndex);
                    }
                    charResolutions[i4] = fontIndex;
                    prevCharResult = RESOLVED;
                    break;
                  }
                }
              }
            }
          }
          if (codePoint > 65535 && i4 + 1 < iLen) {
            charResolutions[i4 + 1] = charResolutions[i4];
            i4++;
            if (prevCharResult === NEEDS_FALLBACK) {
              fallbackRanges[fallbackRanges.length - 1][1] = i4;
            }
          }
        }
        resolveFallbacks();
      })();
    } else {
      fallbackRanges.push([0, text.length - 1]);
      resolveFallbacks();
    }
    function resolveFallbacks() {
      if (fallbackRanges.length) {
        const fallbackString = fallbackRanges.map((range) => text.substring(range[0], range[1] + 1)).join("\n");
        unicodeFontResolverClient.getFontsForString(fallbackString, {
          lang: lang || void 0,
          style,
          weight,
          dataUrl: unicodeFontsURL
        }).then(({ fontUrls, chars }) => {
          const fontIndexOffset = fontResolutions.length;
          let charIdx = 0;
          fallbackRanges.forEach((range) => {
            for (let i4 = 0, endIdx = range[1] - range[0]; i4 <= endIdx; i4++) {
              charResolutions[range[0] + i4] = chars[charIdx++] + fontIndexOffset;
            }
            charIdx++;
          });
          let loadedCount = 0;
          fontUrls.forEach((url, i4) => {
            loadFont(url, (fontObj) => {
              fontResolutions[i4 + fontIndexOffset] = fontObj;
              if (++loadedCount === fontUrls.length) {
                allDone();
              }
            });
          });
        });
      } else {
        allDone();
      }
    }
    function allDone() {
      callback({
        chars: charResolutions,
        fonts: fontResolutions
      });
    }
    function isCodeInRanges(code, ranges) {
      for (let k = 0; k < ranges.length; k++) {
        const [start2, end = start2] = ranges[k];
        if (start2 <= code && code <= end) {
          return true;
        }
      }
      return false;
    }
  };
}
)}
)
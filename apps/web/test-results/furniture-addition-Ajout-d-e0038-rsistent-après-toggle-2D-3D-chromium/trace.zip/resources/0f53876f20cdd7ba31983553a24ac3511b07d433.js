/** <FontResolver>.init **/

troikaDefine(
function init(createFontResolver2, fontParser, unicodeFontResolverClientFactory2) {
    return createFontResolver2(fontParser, unicodeFontResolverClientFactory2());
  }
)
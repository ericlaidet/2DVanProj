/** <<Typr Font Parser> function dependency: woff2otfFactory>.init **/

troikaDefine(
function(){return (
function woff2otfFactory() {
  return function(r2) {
    var e2 = Uint8Array, n2 = Uint16Array, t3 = Uint32Array, a6 = new e2([0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0, 0, 0, 0]), i4 = new e2([0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13, 0, 0]), o2 = new e2([16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15]), f2 = function(r3, e3) {
      for (var a7 = new n2(31), i5 = 0; i5 < 31; ++i5) a7[i5] = e3 += 1 << r3[i5 - 1];
      var o3 = new t3(a7[30]);
      for (i5 = 1; i5 < 30; ++i5) for (var f3 = a7[i5]; f3 < a7[i5 + 1]; ++f3) o3[f3] = f3 - a7[i5] << 5 | i5;
      return [a7, o3];
    }, u = f2(a6, 2), v5 = u[0], s2 = u[1];
    v5[28] = 258, s2[258] = 28;
    for (var l2 = f2(i4, 0)[0], c6 = new n2(32768), g = 0; g < 32768; ++g) {
      var h = (43690 & g) >>> 1 | (21845 & g) << 1;
      h = (61680 & (h = (52428 & h) >>> 2 | (13107 & h) << 2)) >>> 4 | (3855 & h) << 4, c6[g] = ((65280 & h) >>> 8 | (255 & h) << 8) >>> 1;
    }
    var w = function(r3, e3, t4) {
      for (var a7 = r3.length, i5 = 0, o3 = new n2(e3); i5 < a7; ++i5) ++o3[r3[i5] - 1];
      var f3, u2 = new n2(e3);
      for (i5 = 0; i5 < e3; ++i5) u2[i5] = u2[i5 - 1] + o3[i5 - 1] << 1;
      if (t4) {
        f3 = new n2(1 << e3);
        var v6 = 15 - e3;
        for (i5 = 0; i5 < a7; ++i5) if (r3[i5]) for (var s3 = i5 << 4 | r3[i5], l3 = e3 - r3[i5], g2 = u2[r3[i5] - 1]++ << l3, h2 = g2 | (1 << l3) - 1; g2 <= h2; ++g2) f3[c6[g2] >>> v6] = s3;
      } else for (f3 = new n2(a7), i5 = 0; i5 < a7; ++i5) r3[i5] && (f3[i5] = c6[u2[r3[i5] - 1]++] >>> 15 - r3[i5]);
      return f3;
    }, d2 = new e2(288);
    for (g = 0; g < 144; ++g) d2[g] = 8;
    for (g = 144; g < 256; ++g) d2[g] = 9;
    for (g = 256; g < 280; ++g) d2[g] = 7;
    for (g = 280; g < 288; ++g) d2[g] = 8;
    var m = new e2(32);
    for (g = 0; g < 32; ++g) m[g] = 5;
    var b5 = w(d2, 9, 1), p2 = w(m, 5, 1), y = function(r3) {
      for (var e3 = r3[0], n3 = 1; n3 < r3.length; ++n3) r3[n3] > e3 && (e3 = r3[n3]);
      return e3;
    }, L = function(r3, e3, n3) {
      var t4 = e3 / 8 | 0;
      return (r3[t4] | r3[t4 + 1] << 8) >> (7 & e3) & n3;
    }, U = function(r3, e3) {
      var n3 = e3 / 8 | 0;
      return (r3[n3] | r3[n3 + 1] << 8 | r3[n3 + 2] << 16) >> (7 & e3);
    }, k = ["unexpected EOF", "invalid block type", "invalid length/literal", "invalid distance", "stream finished", "no stream handler", , "no callback", "invalid UTF-8 data", "extra field too long", "date not in range 1980-2099", "filename too long", "stream finishing", "invalid zip data"], T = function(r3, e3, n3) {
      var t4 = new Error(e3 || k[r3]);
      if (t4.code = r3, Error.captureStackTrace && Error.captureStackTrace(t4, T), !n3) throw t4;
      return t4;
    }, O = function(r3, f3, u2) {
      var s3 = r3.length;
      if (!s3 || u2 && !u2.l && s3 < 5) return f3 || new e2(0);
      var c7 = !f3 || u2, g2 = !u2 || u2.i;
      u2 || (u2 = {}), f3 || (f3 = new e2(3 * s3));
      var h2, d3 = function(r4) {
        var n3 = f3.length;
        if (r4 > n3) {
          var t4 = new e2(Math.max(2 * n3, r4));
          t4.set(f3), f3 = t4;
        }
      }, m2 = u2.f || 0, k2 = u2.p || 0, O2 = u2.b || 0, A2 = u2.l, x2 = u2.d, E = u2.m, D = u2.n, M = 8 * s3;
      do {
        if (!A2) {
          u2.f = m2 = L(r3, k2, 1);
          var S = L(r3, k2 + 1, 3);
          if (k2 += 3, !S) {
            var V2 = r3[(I = ((h2 = k2) / 8 | 0) + (7 & h2 && 1) + 4) - 4] | r3[I - 3] << 8, _ = I + V2;
            if (_ > s3) {
              g2 && T(0);
              break;
            }
            c7 && d3(O2 + V2), f3.set(r3.subarray(I, _), O2), u2.b = O2 += V2, u2.p = k2 = 8 * _;
            continue;
          }
          if (1 == S) A2 = b5, x2 = p2, E = 9, D = 5;
          else if (2 == S) {
            var j = L(r3, k2, 31) + 257, z = L(r3, k2 + 10, 15) + 4, C = j + L(r3, k2 + 5, 31) + 1;
            k2 += 14;
            for (var F = new e2(C), P = new e2(19), q = 0; q < z; ++q) P[o2[q]] = L(r3, k2 + 3 * q, 7);
            k2 += 3 * z;
            var B = y(P), G = (1 << B) - 1, H = w(P, B, 1);
            for (q = 0; q < C; ) {
              var I, J = H[L(r3, k2, G)];
              if (k2 += 15 & J, (I = J >>> 4) < 16) F[q++] = I;
              else {
                var K = 0, N = 0;
                for (16 == I ? (N = 3 + L(r3, k2, 3), k2 += 2, K = F[q - 1]) : 17 == I ? (N = 3 + L(r3, k2, 7), k2 += 3) : 18 == I && (N = 11 + L(r3, k2, 127), k2 += 7); N--; ) F[q++] = K;
              }
            }
            var Q = F.subarray(0, j), R2 = F.subarray(j);
            E = y(Q), D = y(R2), A2 = w(Q, E, 1), x2 = w(R2, D, 1);
          } else T(1);
          if (k2 > M) {
            g2 && T(0);
            break;
          }
        }
        c7 && d3(O2 + 131072);
        for (var W = (1 << E) - 1, X = (1 << D) - 1, Y = k2; ; Y = k2) {
          var Z = (K = A2[U(r3, k2) & W]) >>> 4;
          if ((k2 += 15 & K) > M) {
            g2 && T(0);
            break;
          }
          if (K || T(2), Z < 256) f3[O2++] = Z;
          else {
            if (256 == Z) {
              Y = k2, A2 = null;
              break;
            }
            var $ = Z - 254;
            if (Z > 264) {
              var rr = a6[q = Z - 257];
              $ = L(r3, k2, (1 << rr) - 1) + v5[q], k2 += rr;
            }
            var er = x2[U(r3, k2) & X], nr = er >>> 4;
            er || T(3), k2 += 15 & er;
            R2 = l2[nr];
            if (nr > 3) {
              rr = i4[nr];
              R2 += U(r3, k2) & (1 << rr) - 1, k2 += rr;
            }
            if (k2 > M) {
              g2 && T(0);
              break;
            }
            c7 && d3(O2 + 131072);
            for (var tr = O2 + $; O2 < tr; O2 += 4) f3[O2] = f3[O2 - R2], f3[O2 + 1] = f3[O2 + 1 - R2], f3[O2 + 2] = f3[O2 + 2 - R2], f3[O2 + 3] = f3[O2 + 3 - R2];
            O2 = tr;
          }
        }
        u2.l = A2, u2.p = Y, u2.b = O2, A2 && (m2 = 1, u2.m = E, u2.d = x2, u2.n = D);
      } while (!m2);
      return O2 == f3.length ? f3 : function(r4, a7, i5) {
        (null == a7 || a7 < 0) && (a7 = 0), (null == i5 || i5 > r4.length) && (i5 = r4.length);
        var o3 = new (r4 instanceof n2 ? n2 : r4 instanceof t3 ? t3 : e2)(i5 - a7);
        return o3.set(r4.subarray(a7, i5)), o3;
      }(f3, 0, O2);
    }, A = new e2(0);
    var x = "undefined" != typeof TextDecoder && new TextDecoder();
    try {
      x.decode(A, { stream: true }), 1;
    } catch (r3) {
    }
    return r2.convert_streams = function(r3) {
      var e3 = new DataView(r3), n3 = 0;
      function t4() {
        var r4 = e3.getUint16(n3);
        return n3 += 2, r4;
      }
      function a7() {
        var r4 = e3.getUint32(n3);
        return n3 += 4, r4;
      }
      function i5(r4) {
        m2.setUint16(b6, r4), b6 += 2;
      }
      function o3(r4) {
        m2.setUint32(b6, r4), b6 += 4;
      }
      for (var f3 = { signature: a7(), flavor: a7(), length: a7(), numTables: t4(), reserved: t4(), totalSfntSize: a7(), majorVersion: t4(), minorVersion: t4(), metaOffset: a7(), metaLength: a7(), metaOrigLength: a7(), privOffset: a7(), privLength: a7() }, u2 = 0; Math.pow(2, u2) <= f3.numTables; ) u2++;
      u2--;
      for (var v6 = 16 * Math.pow(2, u2), s3 = 16 * f3.numTables - v6, l3 = 12, c7 = [], g2 = 0; g2 < f3.numTables; g2++) c7.push({ tag: a7(), offset: a7(), compLength: a7(), origLength: a7(), origChecksum: a7() }), l3 += 16;
      var h2, w2 = new Uint8Array(12 + 16 * c7.length + c7.reduce(function(r4, e4) {
        return r4 + e4.origLength + 4;
      }, 0)), d3 = w2.buffer, m2 = new DataView(d3), b6 = 0;
      return o3(f3.flavor), i5(f3.numTables), i5(v6), i5(u2), i5(s3), c7.forEach(function(r4) {
        o3(r4.tag), o3(r4.origChecksum), o3(l3), o3(r4.origLength), r4.outOffset = l3, (l3 += r4.origLength) % 4 != 0 && (l3 += 4 - l3 % 4);
      }), c7.forEach(function(e4) {
        var n4, t5 = r3.slice(e4.offset, e4.offset + e4.compLength);
        if (e4.compLength != e4.origLength) {
          var a8 = new Uint8Array(e4.origLength);
          n4 = new Uint8Array(t5, 2), O(n4, a8);
        } else a8 = new Uint8Array(t5);
        w2.set(a8, e4.outOffset);
        var i6 = 0;
        (l3 = e4.outOffset + e4.origLength) % 4 != 0 && (i6 = 4 - l3 % 4), w2.set(new Uint8Array(i6).buffer, e4.outOffset + e4.origLength), h2 = l3 + i6;
      }), d3.slice(0, h2);
    }, Object.defineProperty(r2, "__esModule", { value: true }), r2;
  }({}).convert_streams;
}
)}
)